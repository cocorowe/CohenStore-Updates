#include "cohen/update.hpp"
#include "cohen/update_key.hpp"
#include "../vendor/monocypher/monocypher-ed25519.h"
#include <array>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <sys/stat.h>

namespace cohen {
namespace {
template<size_t N> std::array<uint8_t,N> update_hex(const std::string& s) {
    if(s.size()!=N*2) throw std::runtime_error("Invalid update signature or digest length");
    std::array<uint8_t,N> out{};
    auto digit=[](char c)->unsigned {if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;throw std::runtime_error("Invalid update hex encoding");};
    for(size_t i=0;i<N;++i) out[i]=uint8_t(digit(s[2*i])*16+digit(s[2*i+1]));
    return out;
}
}
AppUpdate verify_update(const std::string& raw,uint64_t minimum_revision) {
    if(raw.size()>16384) throw std::runtime_error("Update manifest exceeds limit");
    Json envelope=Json::parse(raw);
    std::string payload=envelope.at("signed_payload").str();
    auto signature=update_hex<64>(envelope.at("signature").str());
    auto key=update_hex<32>(COHEN_UPDATE_PUBLIC_KEY);
    if(crypto_ed25519_check(signature.data(),key.data(),reinterpret_cast<const uint8_t*>(payload.data()),payload.size())!=0)
        throw std::runtime_error("Update publisher signature rejected");
    Json data=Json::parse(payload);
    AppUpdate u;
    u.revision=data.at("revision").u64(); u.version_code=data.at("version_code").u64(); u.version=data.at("version").str();
    if(data.at("schema").u64()!=1 || data.at("channel").str()!="testing" || data.at("title_id").str()!="CHST00001" || data.at("content_id").str()!="IV0000-CHST00001_00-COHENSTORE000000")
        throw std::runtime_error("Update schema, channel or application identity rejected");
    if(!u.revision || u.revision<minimum_revision || u.version_code<APP_VERSION_CODE || u.version_code>999999 || u.version.empty() || u.version.size()>32)
        throw std::runtime_error("Older or invalid update release rejected");
    u.package.id="cohenstore-update-"+std::to_string(u.version_code);
    u.package.title="CohenStore "+u.version; u.package.category="apps";
    u.package.size=data.at("size_bytes").u64(); u.package.sha256=data.at("sha256").str();
    update_hex<32>(u.package.sha256);
    std::string url=data.at("url").str(); allow_url(url);
    auto parsed=parse_url(url);
    if(parsed.scheme!="https" || parsed.host!="raw.githubusercontent.com" || parsed.path.find("/cocorowe/CohenStore-Updates/")!=0)
        throw std::runtime_error("Update package must use the official HTTPS repository");
    if(u.package.size<1024 || u.package.size>256ULL*1024*1024) throw std::runtime_error("Invalid update package size");
    u.package.urls.push_back(url);
    return u;
}
void verify_update_package(const AppUpdate& u,const std::string& path,Cancel cancel) {
    // Read the stream length directly. Some OpenOrbis headers define mode_t
    // twice with different widths, shifting struct stat.st_size on the PS4.
    FILE* size_file=std::fopen(path.c_str(),"rb");
    if(!size_file) throw std::runtime_error("UPD-OPEN: cannot open downloaded package");
    int seek_result=fseeko(size_file,0,SEEK_END);
    off_t actual_size=seek_result==0?ftello(size_file):off_t(-1);
    std::fclose(size_file);
    if(actual_size<0) throw std::runtime_error("UPD-SEEK: cannot measure downloaded package");
    if(uint64_t(actual_size)!=u.package.size)
        throw std::runtime_error("UPD-SIZE: got "+std::to_string(actual_size)+", expected "+std::to_string(u.package.size));
    if(sha256_file(path,cancel)!=u.package.sha256) throw std::runtime_error("UPD-HASH: package SHA-256 mismatch");
    FILE* file=std::fopen(path.c_str(),"rb"); if(!file) throw std::runtime_error("Cannot read update package");
    unsigned char header[128]{}; size_t count=std::fread(header,1,sizeof(header),file); std::fclose(file);
    if(count!=sizeof(header) || std::memcmp(header,"\x7f" "CNT",4)!=0 || std::memcmp(header+0x40,"IV0000-CHST00001_00-COHENSTORE000000",36)!=0)
        throw std::runtime_error("Update PKG identity rejected");
    if(cancel()) throw std::runtime_error("Update cancelled");
}

std::string stage_update_package(const AppUpdate& u,const std::string& source,const std::string& directory,Cancel cancel) {
    verify_update_package(u,source,cancel);
    if(mkdir(directory.c_str(),0700)!=0 && errno!=EEXIST) throw std::runtime_error("Cannot create package staging folder");
    std::string target=directory+"/CohenStore-"+std::to_string(u.version_code)+".pkg";
    if(cancel()) throw std::runtime_error("Update staging cancelled");
    if(std::rename(source.c_str(),target.c_str())!=0) throw std::runtime_error("Cannot stage verified update package");
    return target;
}

}
