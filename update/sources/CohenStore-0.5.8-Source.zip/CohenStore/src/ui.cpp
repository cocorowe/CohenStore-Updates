#include "cohen/ui.hpp"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <sstream>
namespace cohen { namespace ui {
namespace {
Ink bg=0x0b101b,panel=0x121b2b,card=0x172236,white=0xecf2ff,muted=0x98a8c4,cyan=0x57e6c4,purple=0xa78bfa;
uint32_t word(const std::string& bytes,size_t& pos) {
    if(pos+4>bytes.size()) throw std::runtime_error("Font data is truncated");
    const auto* b=reinterpret_cast<const unsigned char*>(bytes.data()+pos); pos+=4;
    return uint32_t(b[0]) | uint32_t(b[1])<<8 | uint32_t(b[2])<<16 | uint32_t(b[3])<<24;
}
Ink mix(Ink a,Ink b,int weight) {
    int inverse=255-weight;
    return (((((a>>16)&255)*inverse+((b>>16)&255)*weight)/255)<<16)
        | (((((a>>8)&255)*inverse+((b>>8)&255)*weight)/255)<<8)
        | (((a&255)*inverse+(b&255)*weight)/255);
}
std::string short_url(const std::string& s) {
    if(s.empty()) return "Direct file link";
    auto at=s.find("://"); return at==std::string::npos?s:s.substr(at+3);
}
std::string size_label(uint64_t n) {
    if(!n) return "Size on connection";
    char b[48];
    if(n>=1024ULL*1024*1024) std::snprintf(b,sizeof(b),"%.1f GB",double(n)/(1024*1024*1024));
    else std::snprintf(b,sizeof(b),"%.1f MB",double(n)/(1024*1024));
    return b;
}
Ink accent(const Item& i) {
    if(i.category=="menus") return purple;
    if(i.category=="updates") return 0x78baff;
    if(i.category=="dlc") return 0xf3b871;
    if(i.category=="homebrew" || i.category=="apps") return cyan;
    return 0x78baff;
}
void pill(Canvas& c,int x,int y,const std::string& t,Ink color) {
    int w=c.measure(t,20)+26; c.rounded(x,y,w,34,12,0x243149); c.text(x+11,y+2,t,20,color,w-18);
}
void button(Canvas& c,int x,int y,int w,const std::string& t,bool enabled) {
    c.rounded(x,y,w,54,16,enabled?cyan:0x273248);
    c.text(x+20,y+9,t,24,enabled?0x0b2022:muted,w-34);
}
void art(Canvas& c,int x,int y,int w,int h,const Item& item) {
    Ink a=accent(item);
    if(!item.title_ids.empty() && c.cover(item.title_ids.front(),x,y,w,h)) return;
    c.gradient(x,y,w,h,mix(0x132039,a,80),mix(0x0e1526,a,22));
    int radius=std::min(w/4,h/3);
    c.circle(x+w*3/4,y+h/3,radius,mix(0x152036,a,45));
    c.circle(x+w*3/4,y+h/3,radius*2/3,mix(0x152036,a,25));
    c.line(x+12,y+h-20,x+w-15,y+14,2,mix(0x223149,a,90));
    if(w>160) {
        c.text(x+24,y+26,item.game.empty()?"COHEN / LIBRARY":item.game,24,white,w-40);
        c.text(x+24,y+h-60,item.category=="menus"?"MOD MENUS":category_title(item.category),28,a,w-35);
    } else {
        std::string label=item.category=="menus"?"GTA":item.category=="updates"?"UPD":item.category=="dlc"?"DLC":item.category=="games"?"PLAY":"APP";
        c.text(x+13,y+h/2-25,label,28,white,w-20);
    }
}
void field(Canvas& c,int x,int y,const std::string& label,const std::string& value,Ink color=white) {
    c.text(x,y,label,20,muted,360); c.text(x,y+31,value,24,color,360);
}
}
void Canvas::load_cover(const std::string& key,const std::string& path) {
    std::string data=read_file(path,1024*1024);
    if(data.substr(0,4)!="CIM1") throw std::runtime_error("Invalid cover header");
    size_t p=4; uint32_t w=word(data,p),h=word(data,p);
    if(!w || !h || w>512 || h>512 || data.size()!=12+size_t(w)*h*3) throw std::runtime_error("Invalid cover dimensions");
    Cover image; image.width=int(w); image.height=int(h); image.rgb.assign(data.begin()+12,data.end());
    covers_[key]=std::move(image);
}
bool Canvas::cover(const std::string& key,int x,int y,int w,int h) {
    auto it=covers_.find(key); if(it==covers_.end()) return false;
    const Cover& im=it->second;
    rect(x,y,w,h,0x101a28);
    double scale=std::min(double(w)/im.width,double(h)/im.height);
    int dw=std::max(1,int(im.width*scale)),dh=std::max(1,int(im.height*scale));
    int left=x+(w-dw)/2,top=y+(h-dh)/2;
    for(int yy=0;yy<dh;++yy) for(int xx=0;xx<dw;++xx) {
        size_t at=(size_t(yy*im.height/dh)*im.width+xx*im.width/dw)*3;
        pixel(left+xx,top+yy,(uint32_t(im.rgb[at])<<16)|(uint32_t(im.rgb[at+1])<<8)|im.rgb[at+2]);
    }
    return true;
}
void Canvas::load_fonts(const std::string& path) {
    std::string bytes=read_file(path,8*1024*1024);
    if(bytes.substr(0,4)!="CFN1") throw std::runtime_error("Invalid UI font atlas");
    size_t p=4; uint32_t count=word(bytes,p);
    if(count>12) throw std::runtime_error("Too many font sizes");
    for(uint32_t n=0;n<count;++n) {
        int size=int(word(bytes,p)); uint32_t chars=word(bytes,p);
        if(size<8 || size>128 || chars>256) throw std::runtime_error("Invalid font size");
        for(uint32_t k=0;k<chars;++k) {
            uint32_t ch=word(bytes,p); Glyph g;
            g.width=int(word(bytes,p)); g.height=int(word(bytes,p)); g.advance=int(word(bytes,p));
            if(g.width<0 || g.height<0 || g.width>256 || g.height>256 || g.advance<0 || g.advance>256) throw std::runtime_error("Invalid glyph");
            size_t len=size_t(g.width)*g.height;
            if(len>bytes.size()-p) throw std::runtime_error("Truncated glyph");
            g.alpha.assign(bytes.begin()+p,bytes.begin()+p+len); p+=len; fonts_[size][int(ch)]=g;
        }
    }
}
void Canvas::pixel(int x,int y,Ink color) {
    if(x>=0 && x<width && y>=0 && y<height) pixels[size_t(y)*width+x]=0x80000000 | (color&0xffffff);
}
void Canvas::rect(int x,int y,int w,int h,Ink color) {
    for(int yy=std::max(0,y);yy<std::min(height,y+h);++yy) {
        int a=std::max(0,x),b=std::min(width,x+w);
        if(a<b) std::fill(pixels.begin()+size_t(yy)*width+a,pixels.begin()+size_t(yy)*width+b,0x80000000 | (color&0xffffff));
    }
}
void Canvas::rounded(int x,int y,int w,int h,int r,Ink color) {
    r=std::max(0,std::min(r,std::min(w,h)/2));
    for(int row=0;row<h;++row) {
        int inset=0,dy=row<r?r-row-1:row>=h-r?row-(h-r):0;
        if(dy>0) inset=r-int(std::sqrt(double(r*r-dy*dy)));
        rect(x+inset,y+row,w-inset*2,1,color);
    }
}
void Canvas::gradient(int x,int y,int w,int h,Ink a,Ink b) {
    for(int row=0;row<h;++row) rect(x,y+row,w,1,mix(a,b,h<=1?0:row*255/(h-1)));
}
void Canvas::line(int x0,int y0,int x1,int y1,int thickness,Ink color) {
    int dx=std::abs(x1-x0),sx=x0<x1?1:-1,dy=-std::abs(y1-y0),sy=y0<y1?1:-1,error=dx+dy;
    for(;;) {
        rect(x0-thickness/2,y0-thickness/2,thickness,thickness,color);
        if(x0==x1 && y0==y1) break;
        int e=2*error; if(e>=dy) {error+=dy;x0+=sx;} if(e<=dx) {error+=dx;y0+=sy;}
    }
}
void Canvas::circle(int x,int y,int r,Ink color) {
    for(int yy=-r;yy<=r;++yy) {
        int span=int(std::sqrt(double(r*r-yy*yy)));
        rect(x-span,y+yy,span*2+1,1,color);
    }
}
int Canvas::measure(const std::string& text,int size) const {
    auto f=fonts_.find(size); if(f==fonts_.end()) return int(text.size())*size/2;
    int w=0; for(unsigned char ch:text) {
        auto it=f->second.find(ch>=32 && ch<127?int(ch):int('?'));
        if(it!=f->second.end()) w+=it->second.advance;
    }
    return w;
}
void Canvas::text(int x,int y,const std::string& text,int size,Ink color,int max_width) {
    auto font=fonts_.find(size); if(font==fonts_.end()) return;
    int origin=x;
    for(unsigned char ch:text) {
        auto it=font->second.find(ch>=32 && ch<127?int(ch):int('?'));
        if(it==font->second.end()) continue;
        const Glyph& g=it->second;
        if(x-origin+g.advance>max_width) break;
        for(int row=0;row<g.height;++row) for(int col=0;col<g.width;++col) {
            int a=g.alpha[size_t(row)*g.width+col];
            int xx=x+col,yy=y+row;
            if(a && xx>=0 && xx<width && yy>=0 && yy<height)
                pixel(xx,yy,mix(pixels[size_t(yy)*width+xx],color,a));
        }
        x+=g.advance;
    }
}
void Canvas::wrap(int x,int y,const std::string& t,int size,Ink color,int max_width,int lines) {
    std::istringstream in(t); std::string word_,row; int n=0;
    while(in>>word_) {
        if(!row.empty() && measure(row+" "+word_,size)>max_width) {
            text(x,y+n*(size+9),row,size,color,max_width);
            if(++n>=lines) return;
            row=word_;
        } else row+=(row.empty()?"":" ")+word_;
    }
    if(!row.empty() && n<lines) text(x,y+n*(size+9),row,size,color,max_width);
}
void Canvas::save_ppm(const std::string& path) const {
    FILE* f=std::fopen(path.c_str(),"wb"); if(!f) throw std::runtime_error("Cannot save UI preview");
    std::fprintf(f,"P6\n%d %d\n255\n",width,height);
    for(uint32_t p:pixels) { unsigned char rgb[3]={static_cast<unsigned char>(p>>16),static_cast<unsigned char>(p>>8),static_cast<unsigned char>(p)}; std::fwrite(rgb,1,3,f); }
    std::fclose(f);
}
const std::vector<std::string>& categories() {
    static const std::vector<std::string> c={"all","games","updates","dlc","homebrew","apps","emulators","menus","favorites","history","store updates","settings"};
    return c;
}
std::string category_title(const std::string& c) {
    if(c=="all") return "Discover";
    if(c=="games") return "Games";
    if(c=="updates") return "Updates";
    if(c=="dlc") return "DLC";
    if(c=="menus") return "Mod menus";
    if(c=="homebrew") return "Homebrew";
    if(c=="apps") return "Apps";
    if(c=="emulators") return "Emulators";
    if(c=="favorites") return "Favorites";
    if(c=="history") return "History";
    if(c=="store updates") return "Store Updates";
    if(c=="settings") return "Settings";
    return c;
}
std::vector<size_t> visible(const View& v) {
    std::vector<size_t> out;
    if(v.queue) { for(size_t i=0;i<v.jobs.size();++i) out.push_back(i); return out; }
    for(size_t i=0;i<v.catalog.items.size();++i) {
        const Item& item=v.catalog.items[i];
        if(v.category!="all" && v.category!="favorites" && v.category!="settings" && v.category!="store updates" && lower(item.category)!=v.category) continue;
        if(lower(item.title).find(lower(v.query))==std::string::npos) continue;
        if(v.category=="menus" && v.version_filter!="all" && !item.game_versions.empty()
            && std::find(item.game_versions.begin(),item.game_versions.end(),v.version_filter)==item.game_versions.end()) continue;
        out.push_back(i);
    }
    return out;
}
void render(Canvas& c,const View& v) {
    bg=v.theme==1?0x150c10:v.theme==2?0x16130b:0x0b101b;
    cyan=v.theme==1?0xef5966:v.theme==2?0xe1b44b:0x57e6c4;
    c.rect(0,0,1920,1080,bg);
    c.gradient(292,0,1628,1080,0x101b2a,bg);
    c.rounded(32,30,250,1020,24,panel);
    c.rounded(58,61,50,50,15,cyan); c.text(68,63,"C",36,0x09251f);
    c.text(120,60,"COHEN",24,white); c.text(120,91,"STORE",20,muted);
    c.text(60,153,"LIBRARY",20,muted);
    const auto& cats=categories();
    for(size_t n=0;n<cats.size();++n) {
        int y=192+int(n)*51; bool active=!v.queue && v.category==cats[n];
        if(active) { c.rounded(47,y-3,218,45,14,0x22394a); c.rounded(47,y+9,4,29,2,cyan); }
        c.text(74,y+5,category_title(cats[n]),20,active?cyan:muted,182);
    }
    c.rounded(49,817,216,64,16,v.queue?0x22394a:0x1b293d);
    c.text(69,831,"Downloads",24,v.queue?cyan:white);
    c.text(69,904,"L1 / R1   Browse",20,muted,190);
    c.text(69,951,"Mint test 0.5.8",20,muted,190);
    c.text(328,41,v.queue?"Downloads":category_title(v.category),48,white,1000);
    c.text(330,109,v.queue?"Downloads are saved with their file type and version.":"Your console. Your collection.",24,muted,1040);
    pill(c,1642,52,v.network_ready?"Downloader ready":"Local library",cyan);
    c.rounded(328,163,1078,62,18,0x18263a);
    c.circle(357,191,8,muted); c.circle(357,191,5,0x18263a); c.line(364,198,372,206,3,muted);
    c.text(390,177,v.query.empty()?"Search titles  /  Triangle":v.query,24,v.query.empty()?muted:white,970);
    bool menus=v.category=="menus" && !v.queue;
    c.rounded(328,249,1078,151,24,menus?0x29233f:0x17313c);
    c.text(357,269,menus?"GTA V, your way.":"Everything in one place.",36,white,990);
    c.text(359,324,menus?"Version labels before you download. Separate plugins, separate choices.":"Games, patches, DLC and tools. Downloads stay in your queue.",20,muted,1000);
    pill(c,359,361,menus?"GTA V / "+v.version_filter+" / CUSA00419":"Retry and resume",menus?purple:cyan);
    auto shown=visible(v);
    c.text(330,419,v.queue?"Your download queue":menus?"Browse mod menus":"Browse your library",24,white,850);
    c.text(1240,422,std::to_string(shown.size())+" entries",20,muted,170);
    int selected=std::max(0,std::min(v.selected,int(shown.size())-1));
    const Item* focus=nullptr;
    const Job* focused_job=nullptr;
    int top=(selected/4)*4;
    for(int n=0;n<4 && top+n<int(shown.size());++n) {
        size_t index=shown[top+n]; const Item& item=v.queue?v.jobs[index].item:v.catalog.items[index];
        bool active=top+n==selected;
        if(active) { focus=&item; if(v.queue) focused_job=&v.jobs[index]; }
        int x=328+(n%2)*550,y=474+(n/2)*210;
        c.rounded(x,y,528,188,20,active?cyan:0x263449);
        c.rounded(x+2,y+2,524,184,18,card);
        art(c,x+18,y+21,112,115,item);
        c.wrap(x+151,y+13,item.title,28,white,357,2);
        c.text(x+151,y+89,item.game_versions.empty()?category_title(item.category):"GTA V  /  "+item.game_versions.front(),20,accent(item),345);
        std::string state=v.queue?v.jobs[index].state:item.downloadable()?size_label(item.size):"Creator reference";
        c.text(x+151,y+124,state,20,item.downloadable()?muted:0xf3b871,345);
        c.text(x+20,y+151,item.format=="prx"?"GoldHEN plugin":"Package",20,muted,465);
    }
    if(shown.empty()) {
        c.rounded(328,474,1078,398,24,card);
        c.circle(866,590,48,0x203246); c.text(851,562,"+",48,cyan);
        c.text(650,671,"Your library starts here",28,white,620);
        c.text(490,727,"Add a verified catalog to browse this category.",24,muted,810);
    }
    c.rounded(1440,163,438,709,24,panel);
    if(focus) {
        art(c,1464,187,390,175,*focus);
        c.wrap(1465,383,focus->title,28,white,384,2);
        field(c,1468,469,focus->category=="menus"?"GAME VERSION":"APP VERSION",focus->game_versions.empty()?(focus->app_version.empty()?"Not specified":focus->app_version):focus->game_versions.front(),focus->game_versions.empty()?muted:cyan);
        field(c,1468,548,"TITLE ID",focus->title_ids.empty()?"Not verified":focus->title_ids.front(),focus->title_ids.empty()?0xf3b871:white);
        c.wrap(1468,631,focused_job && !focused_job->message.empty()?focused_job->message:focus->note.empty()?"Download availability and console compatibility still need testing.":focus->note,20,muted,376,3);
        c.text(1468,727,short_url(focus->source_url),20,muted,370);
        bool resumable=focused_job && (focused_job->state=="paused" || focused_job->state=="failed");
        std::string action=focused_job?(resumable?"X   Resume / retry":focused_job->state=="complete"?"Saved to downloads":"In download queue"):(focus->downloadable()?"X   Add to queue":"Direct file link needed");
        button(c,1466,794,386,action,focused_job?resumable:focus->downloadable());
    } else {
        c.text(1470,199,"Details",28,white,350);
        c.wrap(1470,267,"Choose an entry to see its version, title ID and file type.",24,muted,360,5);
        field(c,1470,482,menus?"YOUR GTA TARGET":"SECTION",menus?"1.56 / CUSA00419":category_title(v.category),cyan);
        c.wrap(1470,613,menus?"Menu downloads stay separate. Combining menus requires a source-code project.":"New entries appear when the catalog refreshes. This section currently has no matching entries.",20,muted,360,5);
    }
    c.rounded(328,906,1550,91,20,0x182438);
    std::string status=v.status;
    if(v.active>=0 && v.active<int(v.jobs.size())) {
        status=v.jobs[v.active].item.title+" / "+v.progress.message;
        c.text(351,915,status,24,white,1480);
        c.rounded(352,966,1499,6,3,0x2a3a51);
        if(v.progress.total) c.rounded(352,966,int(1499*std::min(1.0,double(v.progress.done)/double(v.progress.total))),6,3,cyan);
    } else c.wrap(351,922,status.empty()?"Choose an entry to get started.":status,20,muted,1490,2);
    c.text(331,1018,"X Queue   L3 Favorite   O Pause   Square Downloads   Triangle Search   R2 Menu version   R3 Refresh   Options Exit",20,muted,1530);
    if(!v.queue && (v.category=="settings" || v.category=="store updates")) {
        c.rounded(328,249,1550,623,24,panel);
        c.text(368,282,category_title(v.category),36,white,1400);
        if(v.category=="settings") {
            const std::vector<std::string> labels={"Refresh every 15 minutes","Refresh at startup","Accent theme"};
            for(size_t i=0;i<labels.size();++i) {
                int y=384+int(i)*105;
                if(int(i)==v.setting_index) c.rounded(354,y-11,1480,76,16,0x22394a);
                c.text(383,y,labels[i],28,white,1000);
                c.text(1540,y,i<v.setting_values.size()?v.setting_values[i]:"OFF",28,cyan,265);
            }
            c.text(382,788,"D-pad select  /  X change  /  L1 or R1 browse sections",24,muted,1400);
        } else {
            c.wrap(381,388,"CohenStore checks signed app releases, then verifies the package size, SHA-256 and application identity.",28,white,1390,3);
            c.text(382,555,"R3 Check app update  /  X Check or download  /  R2 Refresh catalog",28,cyan,1350);
            c.wrap(382,636,"After download, close CohenStore. In GoldHEN Package Installer, choose the update from /data/pkg. Circle pauses the download.",24,muted,1360,3);
        }
    }
    if(v.keyboard) {
        c.rounded(465,247,990,565,26,0x2c3b50); c.rounded(468,250,984,559,24,0x172337);
        c.text(507,277,"Search your library",36,white,900); c.text(507,341,v.query,24,cyan,900);
        std::string keys="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ";
        for(size_t i=0;i<keys.size();++i) {
            int x=508+int(i%8)*113,y=412+int(i/8)*63;
            c.rounded(x,y,93,52,12,int(i)==v.key?cyan:0x22344c);
            c.text(x+31,y+6,keys[i]==' '?"_":std::string(1,keys[i]),28,int(i)==v.key?0x0b2022:white,60);
        }
        c.text(509,751,"X  Type      Square  Delete      O  Done",20,muted,900);
    }
}}
}
