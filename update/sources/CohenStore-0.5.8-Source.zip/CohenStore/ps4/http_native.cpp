// OpenOrbis HTTP adapter. Native build checked; console testing is still required.
#include "cohen/store.hpp"
#include <orbis/Http.h>
#include <orbis/Net.h>
#include <orbis/NetCtl.h>
#include <orbis/Ssl.h>
#include <orbis/Sysmodule.h>
#include <orbis/libkernel.h>
#include <array>
#include <sstream>

// Some OpenOrbis declarations omit parameters. Keep the actual ABI at these
// import call sites without enumerating process modules or opening SPRX paths.
extern "C" int cohenHttpHeaderLimit(int,size_t) __asm__("sceHttpSetResponseHeaderMaxSize");
extern "C" int cohenSslTerm(int) __asm__("sceSslTerm");
extern "C" int cohenHttpRedirect(int,int) __asm__("sceHttpSetAutoRedirect");
extern "C" int cohenHttpRecvTimeout(int,uint32_t) __asm__("sceHttpSetRecvTimeOut");

namespace cohen {
namespace {
void http_stage(const char* text) {
    FILE* f=std::fopen("/data/CohenStore-diagnostics.txt","a");
    if(f) {std::fprintf(f,"HTTP: %s\n",text);std::fflush(f);std::fclose(f);}
}
std::string trim_native(std::string s) {
    while(!s.empty() && std::isspace(static_cast<unsigned char>(s.back()))) s.pop_back();
    size_t p=0; while(p<s.size() && std::isspace(static_cast<unsigned char>(s[p]))) ++p;
    return s.substr(p);
}
void require(int rc,const char* operation) {
    if(rc<0) { char b[128]; std::snprintf(b,sizeof(b),"%s failed (0x%08x)",operation,static_cast<unsigned>(rc)); throw std::runtime_error(b); }
}
class NativeTransport : public Transport {
    int pool_=-1,ssl_=-1,http_=-1; bool net_initialized_=false,netctl_initialized_=false;
    void cleanup() {
        if(http_>=0) sceHttpTerm(http_);
        if(ssl_>=0) cohenSslTerm(ssl_);
        if(pool_>=0) sceNetPoolDestroy(pool_);
        if(netctl_initialized_) sceNetCtlTerm();
        if(net_initialized_) sceNetTerm();
        net_initialized_=netctl_initialized_=false; http_=ssl_=pool_=-1;
    }
public:
    NativeTransport() {
        try {
            require(static_cast<int>(sceSysmoduleLoadModuleInternal(ORBIS_SYSMODULE_INTERNAL_NET)),"Load network system module");
            require(static_cast<int>(sceSysmoduleLoadModuleInternal(ORBIS_SYSMODULE_INTERNAL_NETCTL)),"Load network control module");
            require(static_cast<int>(sceSysmoduleLoadModuleInternal(ORBIS_SYSMODULE_INTERNAL_SSL)),"Load TLS system module");
            require(static_cast<int>(sceSysmoduleLoadModuleInternal(ORBIS_SYSMODULE_INTERNAL_HTTP)),"Load HTTP system module");
            require(sceNetInit(),"Initialize network"); net_initialized_=true;
            require(sceNetCtlInit(),"Initialize network control"); netctl_initialized_=true;
            pool_=sceNetPoolCreate("CohenStore",4*1024*1024,0); require(pool_,"Create network pool");
            ssl_=sceSslInit(4*1024*1024); require(ssl_,"Initialize TLS");
            http_=sceHttpInit(pool_,ssl_,4*1024*1024); require(http_,"Initialize HTTP");
        } catch(...) { cleanup(); throw; }
    }
    ~NativeTransport() override { cleanup(); }
    std::string get(const std::string& url,const std::map<std::string,std::string>& headers,Headers on_headers,Body on_body,Cancel cancel) override {
        http_stage("entered request");
        allow_url(url);
        int tmpl=-1,conn=-1,req=-1;
        auto close=[&] {
            if(req>=0) sceHttpDeleteRequest(req);
            if(conn>=0) sceHttpDeleteConnection(conn);
            if(tmpl>=0) sceHttpDeleteTemplate(tmpl);
        };
        try {
            if(cancel()) return "Paused";
            http_stage("create template");
            tmpl=sceHttpCreateTemplate(http_,"CohenStore/0.5.8",2,0); require(tmpl,"Create HTTP template");
            http_stage("set response header limit");
            require(cohenHttpHeaderLimit(tmpl,64*1024),"Set response header limit");
            http_stage("redirect control");
            require(cohenHttpRedirect(tmpl,0),"Disable automatic redirects");
            http_stage("connect timeout");
            require(sceHttpSetConnectTimeOut(tmpl,15000000),"Set connection timeout");
            http_stage("DNS timeout");
            require(sceHttpSetResolveTimeOut(tmpl,15000000),"Set DNS timeout");
            http_stage("receive timeout");
            require(cohenHttpRecvTimeout(tmpl,30000000),"Set receive timeout");
            // TLS certificate checking retains the system defaults.
            http_stage("create connection");
            conn=sceHttpCreateConnectionWithURL(tmpl,url.c_str(),false); require(conn,"Connect to host");
            http_stage("create GET");
            req=sceHttpCreateRequestWithURL(conn,0,url.c_str(),0); require(req,"Create GET request");
            http_stage("add headers");
            for(const auto& h:headers) require(sceHttpAddRequestHeader(req,h.first.c_str(),h.second.c_str(),0),"Set request header");
            http_stage("send request");
            require(sceHttpSendRequest(req,nullptr,0),"Send HTTP request");
            http_stage("read status");
            Response response;
            require(sceHttpGetStatusCode(req,&response.status),"Read HTTP status");
            http_stage("read headers");
            char* raw=nullptr; size_t size=0;
            require(sceHttpGetAllResponseHeaders(req,&raw,&size),"Read response headers");
            if(size>256*1024) throw std::runtime_error("HTTP response headers exceed limit");
            if(raw && size) {
                std::string header_text(raw,size);
                size_t nul=header_text.find('\0'); if(nul!=std::string::npos) header_text.resize(nul);
                std::istringstream in(header_text); std::string line;
                while(std::getline(in,line)) {
                    size_t colon=line.find(':');
                    if(colon!=std::string::npos) response.headers[lower(trim_native(line.substr(0,colon)))]=trim_native(line.substr(colon+1));
                }
            }
            http_stage("read body");
            if(on_headers(response)) {
                std::vector<char> buffer(65536); // Keep the native worker stack small.
                for(;;) {
                    if(cancel()) { sceHttpAbortRequest(req); close(); return "Paused"; }
                    int n=sceHttpReadData(req,buffer.data(),static_cast<uint32_t>(buffer.size()));
                    require(n,"Read download data");
                    if(n==0 || !on_body(buffer.data(),static_cast<size_t>(n))) break;
                }
            }
            http_stage("request completed");
            close(); return "";
        } catch(const std::exception& e) {
            // Only the host is shown; redirected URLs can contain signed tokens.
            std::string error=parse_url(url).host+": "+e.what();
            http_stage(error.c_str()); close(); return error;
        }
    }
};
}
std::unique_ptr<Transport> make_transport() { return std::unique_ptr<Transport>(new NativeTransport()); }
}
