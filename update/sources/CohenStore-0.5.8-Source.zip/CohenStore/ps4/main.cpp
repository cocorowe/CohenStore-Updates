// Native PS4 frontend, using the OpenOrbis Scene2D helper from its graphics sample.
// Repair candidate: console launch still requires testing.
#include "cohen/store.hpp"
#include "cohen/update.hpp"
#include "cohen/ui.hpp"
#include "graphics.h"
#include <orbis/Pad.h>
#ifdef COHEN_PS4_NATIVE
#include <orbis/libkernel.h>
#endif
#include <orbis/UserService.h>
#include <algorithm>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <cctype>
#include <cstdio>
#include <mutex>
#include <sstream>
#include <set>
#include <sys/stat.h>
#include <thread>

std::stringstream debugLogStream; // Required by OpenOrbis sample graphics/log helper.
Scene2D::~Scene2D() {} // OpenOrbis graphics sample declares but omits this destructor.
namespace {
using namespace cohen;
const std::string ROOT="/data/CohenStore";
const std::string DEFAULT_CATALOG_URL="https://raw.githubusercontent.com/cocorowe/CohenStore-Updates/main/catalog/catalog.json";
struct State {
    std::mutex mutex;
    Catalog catalog; std::vector<Job> jobs;
    Progress progress;
    std::string status="Loading local catalog";
    int active=-1;
    std::set<std::string> favorites;
    bool auto_updates=false, check_startup=false, network_ready=false, queue_writable=true; int theme=0;
    std::atomic<bool> stop{false}, pause{false}, refresh{false}, update_check{false}, update_download{false};
    AppUpdate available_update; bool has_update=false;
};
void load_favorites(State& state) {
    try {
        Json data=Json::parse(read_file(ROOT+"/favorites.json",1024*1024));
        if(data.kind==Json::Array) for(const auto& value:data.array) {
            std::string id=value.str(); if(!id.empty() && id.size()<=1024) state.favorites.insert(id);
        }
    } catch(...) {}
}
void save_favorites(const State& state) {
    Json data=Json::arr();
    for(const auto& id:state.favorites) data.array.emplace_back(id);
    write_atomic(ROOT+"/favorites.json",data.dump());
}
void stage(const char* label);
void worker_impl(State& s) {
    std::unique_ptr<Transport> transport;
    std::unique_ptr<Engine> engine;
    auto next_refresh=std::chrono::steady_clock::now()+std::chrono::minutes(15);
    while(!s.stop) {
        { std::lock_guard<std::mutex> lock(s.mutex);
          if(s.auto_updates && std::chrono::steady_clock::now()>=next_refresh) { s.refresh=true; next_refresh=std::chrono::steady_clock::now()+std::chrono::minutes(15); }
        }
        bool wants_refresh=s.refresh.load() || s.update_check.load() || s.update_download.load();
        int queued_index=-1;
        {
            std::lock_guard<std::mutex> lock(s.mutex);
            for(size_t i=0;i<s.jobs.size();++i) if(s.jobs[i].state=="queued") { queued_index=int(i); break; }
        }
        if(!wants_refresh && queued_index<0) {
            std::this_thread::sleep_for(std::chrono::milliseconds(150));
            continue;
        }
        // Keep startup offline-safe: load network modules only when requested.
        if(!engine) {
            try {
                stage("Network initialization requested");
                transport=make_transport();
                engine.reset(new Engine(*transport));
                { std::lock_guard<std::mutex> lock(s.mutex); s.network_ready=true; }
                stage("Network transport ready");
            } catch(const std::exception& e) {
                { std::lock_guard<std::mutex> lock(s.mutex); s.status=std::string("Network initialization failed: ")+e.what(); }
                stage(e.what());
                s.refresh=false; s.update_check=false; s.update_download=false;
                { std::lock_guard<std::mutex> lock(s.mutex);
                  for(auto& job:s.jobs) if(job.state=="queued") { job.state="failed"; job.message=s.status; }
                  if(s.queue_writable) save_queue(ROOT+"/queue.json",s.jobs);
                }
                continue;
            }
        }
        if(s.update_check.exchange(false)) {
            try {
                uint64_t minimum=0;
                struct stat st{};
                if(stat((ROOT+"/update_revision.json").c_str(),&st)==0) {
                    minimum=Json::parse(read_file(ROOT+"/update_revision.json",1024)).at("revision").u64();
                    if(!minimum) throw std::runtime_error("Saved update revision is invalid");
                }
                { std::lock_guard<std::mutex> lock(s.mutex); s.status="Checking signed CohenStore release"; s.has_update=false; }
                AppUpdate update=verify_update(engine->fetch_text(UPDATE_URL,[&]{return s.stop.load();}),minimum);
                write_atomic(ROOT+"/update_revision.json","{\"revision\":"+std::to_string(update.revision)+"}");
                std::lock_guard<std::mutex> lock(s.mutex);
                s.available_update=update; s.has_update=update.version_code>APP_VERSION_CODE;
                s.status=s.has_update?"Update "+update.version+" available. Press X to download.":std::string("CohenStore ")+APP_VERSION+" is up to date";
            } catch(const std::exception& e) { std::lock_guard<std::mutex> lock(s.mutex); s.has_update=false; s.status=e.what(); }
        }
        if(s.update_download.exchange(false)) {
            try {
                AppUpdate update;
                { std::lock_guard<std::mutex> lock(s.mutex); if(!s.has_update) throw std::runtime_error("Check for a newer update first"); update=s.available_update; s.pause=false; }
                auto cancel=[&]{return s.stop.load() || s.pause.load();};
                Result result=engine->download(update.package,ROOT+"/downloads",[&](const Progress& p){std::lock_guard<std::mutex> lock(s.mutex);s.progress=p;},cancel);
                if(!result.ok) throw std::runtime_error(result.error);
                stage_update_package(update,result.path,"/data/pkg",cancel);
                std::lock_guard<std::mutex> lock(s.mutex); s.has_update=false;
                s.status="Update ready. Close CohenStore, then install from GoldHEN Package Installer: /data/pkg";
            } catch(const std::exception& e) { stage(e.what()); std::lock_guard<std::mutex> lock(s.mutex); s.status=e.what(); }
        }
        if(s.refresh.exchange(false)) {
            try {
                std::string url=read_file(ROOT+"/catalog_url.txt",8192);
                while(!url.empty() && std::isspace(static_cast<unsigned char>(url.back()))) url.pop_back();
                if(url.empty()) throw std::runtime_error("Add a catalog URL or import a local catalog first");
                stage("Catalog request started");
                std::string raw=engine->fetch_text(url,[&]{return s.stop.load();});
                Catalog c=catalog_read(raw);
                if(c.items.empty() || !c.warnings.empty()) throw std::runtime_error("New catalog invalid or empty. Existing catalog kept.");
                write_atomic(ROOT+"/catalog.json",raw);
                std::lock_guard<std::mutex> lock(s.mutex); s.catalog=c; s.status="Catalog refreshed: "+std::to_string(c.items.size())+" entries";
                stage("Catalog refresh completed");
            } catch(const std::exception& e) {
                stage(e.what());
                std::lock_guard<std::mutex> lock(s.mutex); s.status=e.what();
            }
        }
        int index=-1; Item item;
        {
            std::lock_guard<std::mutex> lock(s.mutex);
            for(size_t i=0;i<s.jobs.size();++i) if(s.jobs[i].state=="queued") {
                index=int(i); s.active=index; s.jobs[i].state="downloading";
                item=s.jobs[i].item; s.pause=false; s.progress=Progress();
                save_queue(ROOT+"/queue.json",s.jobs); break;
            }
        }
        if(index<0) continue;
        Result result=engine->download(item,ROOT+"/downloads",[&](const Progress& p){
            std::lock_guard<std::mutex> lock(s.mutex); s.progress=p;
        },[&]{return s.stop.load() || s.pause.load();});
        {
            std::lock_guard<std::mutex> lock(s.mutex);
            s.jobs[index].state=result.ok?"complete":result.paused?"paused":"failed";
            s.jobs[index].message=result.ok?(item.format=="prx"?"Plugin saved. Enable manually for the matching game version.":"Downloaded. Install through Package Manager."):result.error;
            s.status=s.jobs[index].message; s.active=-1;
            save_queue(ROOT+"/queue.json",s.jobs);
        }
    }
}
void worker(State& s) {
    try { worker_impl(s); }
    catch(const std::exception& e) {
        std::lock_guard<std::mutex> lock(s.mutex);
        s.status=std::string("Download worker stopped: ")+e.what(); s.active=-1;
    }
}
void stage(const char* label) {
    static std::mutex log_mutex;
    std::lock_guard<std::mutex> lock(log_mutex);
    for(const std::string& path:{ROOT+"/startup.log",std::string("/data/CohenStore-diagnostics.txt")}) {
        struct stat st;
        const char* mode=stat(path.c_str(),&st)==0 && st.st_size>65536?"w":"a";
        FILE* f=std::fopen(path.c_str(),mode);
        if(f) { std::fprintf(f,"%.512s\n",label); std::fflush(f); std::fclose(f); }
    }
}
struct WorkerLifetime {
    State& state;
#ifdef COHEN_PS4_NATIVE
    OrbisPthread thread{}; bool started=false;
    static void* entry(void* data) {worker(*static_cast<State*>(data));return nullptr;}
    explicit WorkerLifetime(State& s):state(s) {
        OrbisPthreadAttr attr{};
        if(scePthreadAttrInit(&attr)!=0) throw std::runtime_error("Cannot create worker attributes");
        int rc=scePthreadAttrSetstacksize(&attr,2*1024*1024);
        if(rc==0) rc=scePthreadCreate(&thread,&attr,entry,&s,"CohenDownloader");
        scePthreadAttrDestroy(&attr);
        if(rc!=0) throw std::runtime_error("Cannot create 2 MiB network worker");
        started=true;
    }
    ~WorkerLifetime() {state.stop=true;state.pause=true;if(started)scePthreadJoin(thread,nullptr);}
#else
    std::thread thread;
    explicit WorkerLifetime(State& s):state(s),thread(worker,std::ref(s)) {}
    ~WorkerLifetime() { state.stop=true; state.pause=true; if(thread.joinable()) thread.join(); }
#endif
};

}
int run_store() {
    using namespace cohen;
    mkdir(ROOT.c_str(),0700);
    stage("0.5.8 signed updater: entered main");
    Scene2D& scene=*new Scene2D(1920,1080,4);
    if(!scene.Init(32*1024*1024,2)) { stage("Video init failed"); return 1; }
    scene.SetActiveFrameBuffer(0);
    stage("Video initialized, frame buffer selected");
    ui::Canvas canvas;
    stage("Canvas allocated");
    try { canvas.load_fonts("/app0/assets/fonts/ui.cfn"); }
    catch(const std::exception& e) { stage(e.what()); return 1; }
    stage("Fonts loaded");
    for(const std::string key:{"SKID02048","RHZR00001"}) {
        try { canvas.load_cover(key,"/app0/assets/art/"+key+".cimg"); } catch(...) {}
    }
    stage("Covers loaded");
    State state;
    try {
        if(mkdir(ROOT.c_str(),0700)!=0 && errno!=EEXIST) throw std::runtime_error("Cannot create Cohen Store data folder");
        struct stat st;
        if(stat((ROOT+"/catalog.json").c_str(),&st)!=0)
            write_atomic(ROOT+"/catalog.json",read_file("/app0/assets/catalog.json"));
        if(stat((ROOT+"/catalog_url.txt").c_str(),&st)!=0) write_atomic(ROOT+"/catalog_url.txt",DEFAULT_CATALOG_URL+"\n");
        std::string configured_url=read_file(ROOT+"/catalog_url.txt",8192);
        if(configured_url.find_first_not_of(" \t\r\n")==std::string::npos)
            write_atomic(ROOT+"/catalog_url.txt",DEFAULT_CATALOG_URL+"\n");
        try {
            state.catalog=catalog_read(read_file(ROOT+"/catalog.json"));
            if(!state.catalog.warnings.empty() || state.catalog.items.empty()) throw std::runtime_error("Cached catalog invalid; bundled catalog loaded");
        } catch(const std::exception& e) {
            stage(e.what()); state.catalog=catalog_read(read_file("/app0/assets/catalog.json"));
        }
        try { state.jobs=load_queue(ROOT+"/queue.json"); }
        catch(const std::exception& e) { state.queue_writable=false; stage(e.what()); }
        load_favorites(state);
        try { std::string cfg=read_file(ROOT+"/settings.json",4096); Json j=Json::parse(cfg); state.auto_updates=(j.at("auto_updates").kind==Json::Bool && j.at("auto_updates").text=="true"); state.check_startup=(j.at("check_startup").kind==Json::Bool && j.at("check_startup").text=="true"); state.theme=int(j.at("theme").u64(1)); if(state.theme<0||state.theme>2) state.theme=1; } catch(...) {}
        if(stat((ROOT+"/mint-layout-v05").c_str(),&st)!=0) {
            Catalog bundled=catalog_read(read_file("/app0/assets/catalog.json"));
            if(state.catalog.warnings.empty() && bundled.warnings.empty()) {
                std::set<std::string> ids;
                for(const auto& item:state.catalog.items) ids.insert(item.id);
                size_t old_size=state.catalog.items.size();
                for(const auto& item:bundled.items) if(ids.insert(item.id).second) state.catalog.items.push_back(item);
                if(old_size!=state.catalog.items.size()) {
                    Json data=Json::obj(),items=Json::arr(); data.object["schema"]=Json::num(1);
                    for(const auto& item:state.catalog.items) items.array.push_back(item.json());
                    data.object["items"]=items;
                    write_atomic(ROOT+"/catalog.before-mint-05.json",read_file(ROOT+"/catalog.json"));
                    write_atomic(ROOT+"/catalog.json",data.dump());
                }
            }
            state.theme=0;
            Json cfg=Json::obj();
            try { cfg=Json::parse(read_file(ROOT+"/settings.json",4096)); } catch(...) {}
            cfg.object["theme"]=Json::num(0);
            cfg.object["check_startup"].kind=Json::Bool; cfg.object["check_startup"].text="false";
            state.check_startup=false;
            write_atomic(ROOT+"/settings.json",cfg.dump());
            write_atomic(ROOT+"/mint-layout-v05","1");
        }
        // First repair launch stays offline even when older settings enabled refresh.
        if(stat((ROOT+"/repair-052").c_str(),&st)!=0) {
            try { write_atomic(ROOT+"/settings.before-052.json",read_file(ROOT+"/settings.json",4096)); } catch(...) {}
            state.check_startup=false; state.auto_updates=false; state.theme=0;
            write_atomic(ROOT+"/settings.json","{\"auto_updates\":false,\"check_startup\":false,\"theme\":0}");
            write_atomic(ROOT+"/repair-052","1");
        }
        state.status=state.catalog.items.empty()?"No catalog entries available. Check the connection or refresh the catalog.":"Ready";
        if(state.auto_updates || state.check_startup) state.refresh=true;
    } catch(const std::exception& e) { state.status=e.what(); }
    if(!state.queue_writable) state.status="Saved queue needs recovery. Existing queue kept; downloads disabled.";
    stage("Local data loaded");
    sceUserServiceInitialize(nullptr);
    int user=0; sceUserServiceGetInitialUser(&user); scePadInit();
    int pad=scePadOpen(user,0,0,nullptr);
    stage("Controller initialized");
    std::unique_ptr<WorkerLifetime> background;
    uint32_t previous=0; int frame=0,selected=0,category=0,key=0;
    bool queue_view=false,keyboard=false; std::string query,menu_version="1.56";
    const std::vector<std::string> categories={"all","games","updates","dlc","homebrew","apps","emulators","mod menus","favorites","download history","store updates","settings"};
    const std::string keys="ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ";
    while(!state.stop) {
        OrbisPadData input={}; uint32_t now=0;
        if(pad>=0 && scePadReadState(pad,&input)>=0) now=input.buttons;
        uint32_t pressed=now&~previous; previous=now;
        if(pressed&0x0008) { state.stop=true; break; } // Options: quit.
        std::unique_lock<std::mutex> lock(state.mutex);
        if(!keyboard) {
            if(pressed&0x0400) { category=(category+int(categories.size())-1)%int(categories.size()); selected=0; queue_view=false; }
            if(pressed&0x0800) { category=(category+1)%int(categories.size()); selected=0; queue_view=false; }
            if(pressed&0x8000) { queue_view=!queue_view; selected=0; }
        }
        if(!keyboard && category==7 && (pressed&0x0200)) { menu_version=menu_version=="1.56"?"1.57":menu_version=="1.57"?"all":"1.56"; selected=0; }
        std::vector<size_t> shown;
        if(queue_view) for(size_t i=0;i<state.jobs.size();++i) shown.push_back(i);
        else if(category==9) for(size_t i=0;i<state.jobs.size();++i) {
            if(state.jobs[i].state=="complete" && lower(state.jobs[i].item.title).find(lower(query))!=std::string::npos) shown.push_back(i);
        }
        else if(category<8 || category==8) for(size_t i=0;i<state.catalog.items.size();++i) {
            const auto& item=state.catalog.items[i];
            bool matches_category=category==0 || (category==7?(lower(item.category)=="mod_menus" || lower(item.category)=="menus"):category==8?state.favorites.count(item.id)>0:lower(item.category)==categories[category]);
            if(category==7 && menu_version!="all" && !item.game_versions.empty() && std::find(item.game_versions.begin(),item.game_versions.end(),menu_version)==item.game_versions.end()) continue;
            if(matches_category && lower(item.title).find(lower(query))!=std::string::npos) shown.push_back(i);
        }
        if(pressed&0x1000) keyboard=!keyboard; // Triangle: search.
        if(keyboard) {
            if(pressed&0x0010) key=(key+int(keys.size())-8)%int(keys.size());
            if(pressed&0x0040) key=(key+8)%int(keys.size());
            if(pressed&0x0080) key=(key+int(keys.size())-1)%int(keys.size());
            if(pressed&0x0020) key=(key+1)%int(keys.size());
            if((pressed&0x4000) && query.size()<48) { query+=keys[key]; selected=0; }
            if((pressed&0x8000) && !query.empty()) { query.pop_back(); selected=0; }
            if(pressed&0x2000) keyboard=false;
        } else {
            if(!queue_view && category==11) {
                if(pressed&0x0010) selected=(selected+2)%3;
                if(pressed&0x0040) selected=(selected+1)%3;
                if(pressed&0x4000) {
                    if(selected==0) { state.auto_updates=!state.auto_updates; if(state.auto_updates) state.refresh=true; }
                    else if(selected==1) state.check_startup=!state.check_startup;
                    else state.theme=(state.theme+1)%3;
                    std::string cfg="{\"auto_updates\":"+std::string(state.auto_updates?"true":"false")+",\"check_startup\":"+std::string(state.check_startup?"true":"false")+",\"theme\":"+std::to_string(state.theme)+"}";
                    try { write_atomic(ROOT+"/settings.json",cfg); state.status="Settings saved"; } catch(const std::exception& e) { state.status=e.what(); }
                }
            } else if(!queue_view && category==10) {
                if(pressed&0x4000) { if(state.has_update) state.update_download=true; else state.update_check=true; }
                if(pressed&0x0004) { state.update_check=true; state.status="Checking for CohenStore updates"; }
                if(pressed&0x0200) { state.refresh=true; state.status="Refreshing catalog"; }
                if(pressed&0x2000) state.pause=true;
            } else {
            selected=std::max(0,std::min(selected,int(shown.size())-1));
            if((pressed&0x0002) && !queue_view && category<9 && !shown.empty()) {
                const std::string& id=state.catalog.items[shown[selected]].id;
                if(state.favorites.count(id)) state.favorites.erase(id); else state.favorites.insert(id);
                try { save_favorites(state); state.status="Favorite saved"; }
                catch(const std::exception& e) { state.status=e.what(); }
            }
            if(pressed&0x0010) selected-=2;
            if(pressed&0x0040) selected+=2;
            if(pressed&0x0080) --selected;
            if(pressed&0x0020) ++selected;
            selected=std::max(0,std::min(selected,int(shown.size())-1));
            if((pressed&0x4000) && !shown.empty()) {
                size_t i=shown[selected];
                try {
                    if(queue_view || category==9) {
                        if(state.jobs[i].state=="paused" || state.jobs[i].state=="failed") {
                            for(const auto& latest:state.catalog.items) if(latest.id==state.jobs[i].item.id) {
                                state.jobs[i].item=latest; break;
                            }
                            if(!state.jobs[i].item.downloadable()) throw std::runtime_error("No current download link. Refresh the catalog first.");
                            state.jobs[i].message.clear();
                            state.jobs[i].state="queued";
                        }
                    } else {
                        if(!state.queue_writable) throw std::runtime_error("Saved queue needs recovery before adding downloads");
                        Item item=state.catalog.items[i];
                        if(!item.downloadable()) throw std::runtime_error("Creator reference only. No verified direct file is available.");
                        bool found=false;
                        for(auto& job:state.jobs) if(job.item.id==item.id) {
                            found=true;
                            if(job.state=="failed" || job.state=="paused") {
                                job.item=item; job.message.clear(); job.state="queued";
                            }
                        }
                        if(!found) { Job job; job.item=item; state.jobs.push_back(job); }
                        state.status="Added to download queue";
                    }
                    save_queue(ROOT+"/queue.json",state.jobs);
                } catch(const std::exception& e) { state.status=e.what(); }
            }
            if(pressed&0x2000) state.pause=true;
            if(pressed&0x0004) state.refresh=true; // R3: refresh.
            }
        }
        ui::View view;
        view.category=category==7?"menus":category==9?"history":category==10?"store updates":categories[category];
        view.query=query; view.selected=selected; view.key=key; view.keyboard=keyboard;
        view.queue=queue_view || category==9; view.progress=state.progress;
        view.status=state.status; view.version_filter=menu_version; view.theme=state.theme;
        view.network_ready=state.network_ready;
        if(view.queue) {
            for(size_t index:shown) view.jobs.push_back(state.jobs[index]);
            auto active=std::find(shown.begin(),shown.end(),size_t(state.active));
            if(active!=shown.end()) view.active=int(active-shown.begin());
        } else {
            for(size_t index:shown) { Item item=state.catalog.items[index]; if(item.category=="mod_menus") item.category="menus"; view.catalog.items.push_back(item); }
            view.jobs=state.jobs; view.active=state.active;
        }
        view.setting_index=selected;
        view.setting_values={state.auto_updates?"ON":"OFF",state.check_startup?"ON":"OFF",state.theme==0?"MINT":state.theme==1?"RED":"GOLD"};
        lock.unlock();
        ui::render(canvas,view);
        scene.CopyFrame(canvas.pixels.data());
        if(frame==0) stage("First frame rendered");
        scene.SubmitFlip(frame); scene.FrameWait(frame); scene.FrameBufferSwap();
        if(frame==0) { stage("First frame presented"); background.reset(new WorkerLifetime(state)); stage("Worker started after first frame"); }
        ++frame;
    }
    state.stop=true; state.pause=true;
    background.reset();
    if(pad>=0) scePadClose(pad);
    return 0;
}

int main() {
    try { return run_store(); }
    catch(const std::exception& e) { stage(e.what()); return 1; }
    catch(...) { stage("Unhandled startup failure"); return 1; }
}
