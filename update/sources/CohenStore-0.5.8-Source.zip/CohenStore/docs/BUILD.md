# Building CohenStore

## Linux development client

Requires a C++17 compiler, make, Python 3, and libcurl development headers and
library.

    make clean test

Updater tests and release signing also require Python cryptography.

The desktop output `build/cohen-store` is for development and cannot be
installed on a PS4.

## Native PS4 build

Requires the OpenOrbis PS4 Toolchain release, LLVM/Clang, make, and the runtime
libraries required by `PkgTool.Core`.

1. Extract the OpenOrbis toolchain archive and keep its `include`, `lib`,
   `samples`, and `bin/linux` directories.
2. Extract the LLVM archive and add its `bin` directory to `PATH`.
3. Extract the Debian `libssl1.1` package to a directory (do not install it into
   the host OS unless you intentionally manage that dependency).
4. Set the environment, adjusting paths for your machine:

       export OO_PS4_TOOLCHAIN=/absolute/path/to/OpenOrbis/PS4Toolchain
       export PATH=/absolute/path/to/llvm-18.1.8-x86_64/bin:$PATH
       export DOTNET_SYSTEM_GLOBALIZATION_INVARIANT=1
       export LD_LIBRARY_PATH=/absolute/path/to/libssl/usr/lib/x86_64-linux-gnu:$LD_LIBRARY_PATH

5. Check prerequisites and build:

       python3 tools/build_ps4.py --check
       python3 tools/build_ps4.py

The build copies the SDK graphics sample into `build/ps4-work`, injects the
CohenStore native sources, builds an Orbis executable, generates package
metadata, and creates a debug/fake PKG. It does not modify the installed SDK.

Output: `dist/CohenStore-0.5.8-UPDATER-TEST.pkg`.

Run the same command with `--recovery` for
`dist/CohenStore-Recovery-0.5.2.pkg` (separate title ID CHST00002).
The two builds reuse the same private work folder, so run them sequentially.

The PKG must be validated and then installed/launched on a real console before
it can be considered usable. This project has not been console-tested on
firmware 13.52. Keep a known-good older package for rollback.

## Controller mappings in the current native prototype

- D-pad: move through entries and the search keyboard.
- X: add an item to the download queue; retry paused/failed queue entries.
- Circle: pause the active transfer.
- Square: open/close the download queue.
- Triangle: open/close the on-screen search keyboard.
- L3: toggle the selected item's favorite state.
- L1/R1: change category.
- R3: request a catalog refresh.
- Options: exit.

## Runtime data

The native app stores its data under `/data/CohenStore/`:

- `catalog.json`: local catalog cache.
- `catalog_url.txt`: catalog feed URL.
- `queue.json`: persistent download queue and completed records.
- `favorites.json`: persistent favorites.
- `settings.json`: theme and catalog-check preferences.
- `downloads/`: partial and completed packages with verification receipts.

## Catalog schema

A catalog has `schema: 1` and an `items` array. Each item needs a stable `id`,
`title`, `category`, and one or more direct HTTP(S) URLs. Exact `size_bytes` and
publisher SHA-256 values should be supplied when known. Unknown sizes must be
zero, not estimates. Share pages are not direct package links.

Commercial game packages must not be listed for redistribution without the
rights holder's authorization. `.prx` plugins are not PKGs and require their
own installation workflow.
