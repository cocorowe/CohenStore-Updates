#!/usr/bin/env python3
"""Native build using an installed OpenOrbis graphics sample.

The SDK, clang/lld and packaging tools are external prerequisites. This script
does not synthesize an eboot or rename a desktop binary to .pkg.
"""
import argparse
import os
from pathlib import Path
import re
import shlex
import shutil
import struct
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
TITLE_ID = "CHST00001"
CONTENT_ID = "IV0000-CHST00001_00-COHENSTORE000000"


def read_sfo(blob):
    magic, version, keys, values, count = struct.unpack_from("<5I", blob)
    if magic != 0x46535000 or version != 0x101 or count > 1024:
        raise ValueError("Invalid SDK sample param.sfo")
    rows = []
    for i in range(count):
        key_off, fmt, length, capacity, value_off = struct.unpack_from("<HHIII", blob, 20 + i*16)
        key_start = keys + key_off
        name = blob[key_start:blob.index(b"\0", key_start)].decode()
        value = blob[values+value_off:values+value_off+length]
        if len(value) != length or length > capacity:
            raise ValueError("Invalid SFO value")
        rows.append((name, fmt, value, capacity))
    return rows


def write_sfo(rows):
    names = bytearray()
    data = bytearray()
    records = bytearray()
    for name, fmt, value, capacity in rows:
        capacity = max(capacity, len(value))
        capacity = (capacity+3) & ~3
        key_off = len(names)
        names.extend(name.encode() + b"\0")
        records.extend(struct.pack("<HHIII", key_off, fmt, len(value), capacity, len(data)))
        data.extend(value)
        data.extend(b"\0" * (capacity-len(value)))
    key_base = 20 + len(records)
    value_base = (key_base+len(names)+3) & ~3
    return struct.pack("<5I", 0x46535000, 0x101, key_base, value_base, len(rows)) + records + names + b"\0"*(value_base-key_base-len(names)) + data


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--sdk", default=os.environ.get("OO_PS4_TOOLCHAIN"))
    parser.add_argument("--compiler-bin", default=os.environ.get("LLVM_BIN"))
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--recovery", action="store_true", help="Build a separate offline diagnostic app")
    args = parser.parse_args()
    env = dict(os.environ)
    if args.compiler_bin:
        env["PATH"] = str(Path(args.compiler_bin).expanduser().resolve()) + os.pathsep + env.get("PATH", "")
    missing = []
    if not args.sdk:
        missing.append("OO_PS4_TOOLCHAIN is not set to an installed SDK release")
        sdk = Path("/SDK_NOT_INSTALLED")
    else:
        sdk = Path(args.sdk).expanduser().resolve()
    for tool in ("clang++", "ld.lld", "make"):
        if not shutil.which(tool, path=env.get("PATH")):
            missing.append(f"{tool} is not installed")
    for path in ("include/orbis/Http.h", "lib/crt1.o", "samples/graphics/Makefile",
                 "samples/_common/graphics.cpp", "samples/_common/graphics.h",
                 "bin/linux/create-fself", "bin/linux/PkgTool.Core"):
        if not (sdk/path).is_file():
            missing.append(f"Missing SDK file: {path}")
    if missing:
        print("PS4 build blocked:\n- " + "\n- ".join(missing), file=sys.stderr)
        return 2
    if args.check:
        print("Build prerequisites found.")
        return 0
    sample = sdk/"samples/graphics"
    work = ROOT/"build/ps4-work/samples/graphics"
    if work.exists():
        shutil.rmtree(work)
    work.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(sample, work)
    common = work.parent/"_common"
    if common.exists():
        shutil.rmtree(common)
    shutil.copytree(sdk/"samples/_common", common)
    # Initialize the SDK sample's otherwise indeterminate frame-buffer index.
    header = common/"graphics.h"
    header.write_text(header.read_text().replace("void FrameBufferClear();", "void FrameBufferClear();\n    void CopyFrame(const uint32_t *pixels);"))
    graphics = common/"graphics.cpp"
    graphics_source=graphics.read_text()
    graphics_source=graphics_source.replace('this->width = w;', 'this->activeFrameBufferIdx = 0;\n\tthis->frameBufferCount = 0;\n\tthis->frameBuffers = nullptr;\n\tthis->width = w;')
    graphics_source=graphics_source.replace('this->frameBuffers = new char*[num];','this->frameBufferCount = num;\n\tthis->frameBuffers = new char*[num];')
    graphics.write_text('#include <string.h>\n'+graphics_source+'\nvoid Scene2D::CopyFrame(const uint32_t *pixels) { if (!pixels || !this->frameBuffers || this->activeFrameBufferIdx < 0 || this->activeFrameBufferIdx >= this->frameBufferCount) return; memcpy(this->frameBuffers[this->activeFrameBufferIdx], pixels, size_t(this->width)*this->height*4); }\n')
    assets = work/"assets"
    assets.mkdir(exist_ok=True)
    shutil.copytree(ROOT/"assets/fonts",assets/"fonts",dirs_exist_ok=True)
    shutil.copytree(ROOT/"assets/art",assets/"art",dirs_exist_ok=True)
    shutil.copy2(ROOT/"catalog/catalog.json", assets/"catalog.json")
    sfo = work/"sce_sys/param.sfo"
    # Release SDK samples generate their SFO on the first make invocation.
    old = {"TITLE_ID":"BREW00082", "CONTENT_ID":"IV0000-BREW00082_00-GRAPHICSEX000000"}
    title_id="CHST00002" if args.recovery else TITLE_ID
    content_id="IV0000-CHST00002_00-COHENRECOVERY000" if args.recovery else CONTENT_ID
    if len(content_id)!=36:
        raise RuntimeError("Package content ID must have exactly 36 characters")
    replacements = {"TITLE":"Cohen Recovery" if args.recovery else "Cohen Store", "TITLE_ID":title_id, "CONTENT_ID":content_id,
                    "APP_VER":"00.58", "VERSION":"01.00"}
    main_files = list(work.glob("*/main.cpp"))
    if len(main_files) != 1:
        raise RuntimeError("SDK graphics sample layout differs. Review build integration.")
    sources = ["src/catalog.cpp","src/download.cpp","src/sha256.cpp","src/ui.cpp","vendor/monocypher/monocypher.c","vendor/monocypher/monocypher-ed25519.c","src/update.cpp","ps4/http_native.cpp","ps4/main.cpp"]
    if args.recovery:
        sources=["ps4/recovery.cpp"]
    main_files[0].write_text("".join('#include "'+str(ROOT/source)+'"\n' for source in sources))
    makefile = work/"Makefile"
    recipe = makefile.read_text()
    # Keep the sample's native startup, FSELF flags and runtime modules.
    # Add only this project's includes and additional system import libraries.
    if "clang++" not in recipe or "-lkernel" not in recipe:
        raise RuntimeError("SDK makefile layout differs. Review compiler/linker integration.")
    recipe = recipe.replace("clang++","clang++ -O2 -std=c++17 -D_GNU_SOURCE -DCOHEN_PS4_NATIVE -I"+shlex.quote(str(ROOT/"include"))+" -I"+shlex.quote(str(common)))
    recipe = recipe.replace("-lkernel", "-lkernel -lScePad -lSceUserService" + ("" if args.recovery else " -lSceNet -lSceNetCtl -lSceSsl -lSceHttp -lSceSysmodule"))
    recipe = re.sub(r"^TITLE\s*:=.*$", "TITLE := Cohen Store", recipe, flags=re.M)
    recipe = re.sub(r"^COMMONDIR\s*:=.*$", "COMMONDIR := "+str(common), recipe, flags=re.M)
    recipe = re.sub(r"^ASSETS\s*:=.*$", "ASSETS := assets/catalog.json", recipe, flags=re.M)
    for name in ("CONTENT_ID","TITLE_ID"):
        if old.get(name):
            recipe = recipe.replace(old[name],replacements[name])
    makefile.write_text(recipe)
    for descriptor in work.glob("*.gp4"):
        content = descriptor.read_text()
        for name in ("TITLE_ID","CONTENT_ID"):
            if old.get(name):
                content = content.replace(old[name],replacements[name])
        descriptor.write_text(content)
    icon = ROOT/"assets/icon0.png"
    if icon.exists():
        shutil.copy2(icon, work/"sce_sys/icon0.png")
    env["OO_PS4_TOOLCHAIN"] = str(sdk)
    env.setdefault("DOTNET_SYSTEM_GLOBALIZATION_INVARIANT", "1")
    bundle = ROOT/"build/dotnet-cache"
    bundle.mkdir(parents=True, exist_ok=True)
    env.setdefault("DOTNET_BUNDLE_EXTRACT_BASE_DIR", str(bundle))
    subprocess.run(["make", "eboot.bin", "sce_sys/param.sfo"],cwd=work,env=env,check=True)
    package_files = ["eboot.bin", "sce_sys/about/right.sprx", "sce_sys/param.sfo", "sce_sys/icon0.png"]
    package_files += [str(p.relative_to(work)) for p in sorted(assets.rglob("*")) if p.is_file()]
    package_files += [str(p.relative_to(work)) for p in sorted((work/"sce_module").glob("*")) if p.is_file()]
    gp4 = work/"pkg.gp4"
    subprocess.run([str(sdk/"bin/linux/create-gp4"),"-out",str(gp4),"--content-id="+content_id,"--files"," ".join(package_files)],cwd=work,env=env,check=True)
    tree = ET.parse(gp4)
    files = tree.getroot().find("files")
    if files is None:
        raise RuntimeError("GP4 has no files section")
    if not any(f.get("targ_path") == "assets/catalog.json" for f in files):
        ET.SubElement(files,"file",{"targ_path":"assets/catalog.json","orig_path":"assets/catalog.json"})
    # Packaging templates vary, so retain the rest of the SDK's GP4 unchanged.
    rootdir = tree.getroot().find("rootdir")
    if rootdir is None:
        raise RuntimeError("GP4 has no directory section")
    for relative in package_files:
        node = rootdir
        for component in Path(relative).parts[:-1]:
            child = next((d for d in node.findall("dir") if d.get("targ_name")==component),None)
            if child is None:
                child = ET.SubElement(node,"dir",{"targ_name":component})
            node = child
    tree.write(gp4,encoding="utf-8",xml_declaration=True)
    # Reassert metadata in case the sample's make rules regenerated the SFO.
    rows = read_sfo(sfo.read_bytes())
    sfo.write_bytes(write_sfo([(name,fmt,(replacements[name].encode()+b"\0") if name in replacements else value,cap) for name,fmt,value,cap in rows]))
    subprocess.run([str(sdk/"bin/linux/PkgTool.Core"),"pkg_build",str(gp4),str(work)],cwd=work,env=env,check=True)
    packages = [p for p in work.glob("*.pkg") if content_id in p.name]
    if len(packages) != 1:
        raise RuntimeError("Expected one new Cohen Store package; no distributable produced")
    with packages[0].open("rb") as handle:
        header = handle.read(1024)
    if header[:4] != b"\x7fCNT" or content_id.encode() not in header:
        raise RuntimeError("Package identity validation failed")
    subprocess.run([str(sdk/"bin/linux/PkgTool.Core"),"pkg_validate",str(packages[0])],cwd=work,env=env,check=True)
    dist = ROOT/"dist"
    dist.mkdir(exist_ok=True)
    target = dist/("CohenStore-Recovery-0.5.2.pkg" if args.recovery else "CohenStore-0.5.8-UPDATER-TEST.pkg")
    shutil.copy2(packages[0],target)
    print(f"Compiled package: {target}")
    print("Not console-tested. No firmware compatibility claim is made.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, RuntimeError, subprocess.CalledProcessError) as error:
        print(f"PS4 build failed: {error}",file=sys.stderr)
        raise SystemExit(1)
