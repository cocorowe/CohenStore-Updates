# CohenStore 0.4.1 repair candidate

The launch crash reported on PS4 is not confirmed fixed. This is a diagnostic
repair build, not a stable release. Keep the working 0.2 installer.

Preserved: three themes, favorites, saved settings, search, category browsing,
queue, history, retry/resume, catalog refresh and deferred networking.

Fixed a reproducible queue-to-catalog out-of-bounds access by processing section
and queue transitions before generating indexes. A host harness compiling the
native main with checked vectors aborts on original 0.4 and passes on the repair.
This harness stubs display/controller APIs and does not validate PS4 runtime.

Corrected Settings and Store Updates display category indexes. Added a catch
boundary around worker file operations so an I/O exception reports a status
instead of escaping the thread. Corrected the TLS cleanup call to pass its
context ID. Scene ownership follows the original process-lifetime pattern.

Build: OpenOrbis 0.5.4 and LLVM 18.1.8. All 39 local tests pass. Native compilation,
linking, FSELF generation, packaging and package validation pass. Extracted
catalog bytes match the source. The original three catalog entries are retained;
no game or mod-menu catalog was added. Console installation, launch and native
networking remain untested. SDK binaries are not included in the source ZIP.

Application label: 0.4.1 repair test. SFO APP_VER: 00.05.

Install the repair PKG using the existing GoldHEN Package Installer. If it still
closes at launch, retrieve /data/CohenStore/startup.log using FTP or PS4-Xplorer.
Report if that file does not exist. Its last stage helps locate the failure;
no log can mean failure before main, or inability to write the data folder.
Do not delete catalog, favorites, settings or queue data for this test.

Package SHA256:
e8c6d2662ee97fc27c6ada6a6d1750704f5a513682c19ff1e9822504b66f4b3f
