#!/usr/bin/env python3
"""Check bounded package prefixes. Does not download whole games."""
import argparse
import re
from catalog_tools import allowed, is_page, load_json, request, save_json


def probe(url, file_format="pkg"):
    allowed(url)
    if is_page(url):
        return {"ok": False, "reason": "Provider webpage; no direct file URL"}
    response, final_url = request(url, {"Range": "bytes=0-3", "Accept-Encoding": "identity"})
    with response:
        status = response.code
        kind = response.headers.get("Content-Type", "")
        if status not in (200, 206):
            return {"ok": False, "reason": f"HTTP {status}"}
        if "text/html" in kind.lower():
            return {"ok": False, "reason": "HTML webpage returned"}
        prefix = response.read(4)
        signatures = (b"\x4f\x15\x3d\x1d", b"\x7fELF") if file_format == "prx" else (b"\x7fCNT",)
        if prefix not in signatures:
            return {"ok": False, "reason": f"Not a {file_format} prefix"}
        total = None
        match = re.fullmatch(r"bytes 0-(\d+)/(\d+)", response.headers.get("Content-Range", ""))
        if status == 206 and not match:
            return {"ok": False, "reason": "Invalid prefix range response"}
        if match:
            total = int(match.group(2))
        elif response.headers.get("Content-Length", "").isdigit():
            total = int(response.headers["Content-Length"])
        return {
            "ok": True,
            "final_host": allowed(final_url).hostname,
            "size_bytes": total,
            "etag": response.headers.get("ETag"),
            "checked": f"HTTP access and 4-byte {file_format} prefix only. No full transfer or compatibility test.",
        }


def main():
    p = argparse.ArgumentParser()
    p.add_argument("catalog")
    p.add_argument("--limit", type=int, default=10)
    p.add_argument("--output", default="catalog-audit.json")
    args = p.parse_args()
    result = []
    for item in load_json(args.catalog).get("items", [])[:max(0, args.limit)]:
        if not item.get("urls"):
            result.append({"id": item["id"], "title": item["title"], "ok": False, "reason": "Creator reference; no direct download"})
        for url in item.get("urls", []):
            row = {"id": item["id"], "title": item["title"]}
            try:
                row.update(probe(url, item.get("format", "pkg")))
            except Exception as e:
                row.update(ok=False, reason=str(e))
            result.append(row)
    save_json(args.output, result)
    print(f"Checked {len(result)} URLs. Full download reliability remains untested.")


if __name__ == "__main__":
    main()
