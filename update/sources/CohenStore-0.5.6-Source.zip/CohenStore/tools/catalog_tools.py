"""Catalog import/audit helpers for the standalone Cohen Store."""
import hashlib
import json
from pathlib import Path
import urllib.error
import urllib.parse
import urllib.request

MAX_JSON = 32 * 1024 * 1024


def allowed(url):
    p = urllib.parse.urlsplit(url)
    host = (p.hostname or "").lower().rstrip(".")
    if p.scheme not in ("http", "https") or not host or p.username or p.password:
        raise ValueError("Expected an HTTP(S) URL without embedded credentials")
    if any(ord(c) <= 32 for c in url) or "\\" in url or "%" in p.netloc:
        raise ValueError("Invalid URL authority or control character")
    if host == "archive.org" or host.endswith(".archive.org"):
        raise ValueError("Internet Archive excluded")
    return p


def is_page(url):
    p = allowed(url)
    h = p.hostname.lower().rstrip(".")
    return (
        (h in ("vikingfile.com", "vik1ngfile.site") and p.path.startswith("/f/"))
        or (h in ("akirabox.com", "akirabox.to") and "/uploads/" not in p.path)
        or h in ("1fichier.com", "mega.nz", "gofile.io")
        or (h.endswith("mediafire.com") and p.path.startswith("/file/"))
    )


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def request(url, headers=None):
    opener = urllib.request.build_opener(NoRedirect())
    initial_scheme = allowed(url).scheme
    for _ in range(6):
        allowed(url)
        if initial_scheme == "https" and urllib.parse.urlsplit(url).scheme != "https":
            raise ValueError("HTTPS downgrade refused")
        req = urllib.request.Request(
            url, headers={"User-Agent": "CohenStore-CatalogTools/0.1", **(headers or {})}
        )
        try:
            response = opener.open(req, timeout=20)
        except urllib.error.HTTPError as e:
            response = e
        if response.code in (301, 302, 303, 307, 308):
            destination = response.headers.get("Location")
            response.close()
            if not destination:
                raise ValueError("Redirect without destination")
            url = urllib.parse.urljoin(url, destination)
            continue
        return response, url
    raise ValueError("Too many redirects")


def load_json(source):
    if source.startswith(("http://", "https://")):
        response, _ = request(source)
        with response:
            if response.code != 200:
                raise ValueError(f"Catalog HTTP {response.code}")
            data = response.read(MAX_JSON + 1)
    else:
        data = Path(source).read_bytes()
    if len(data) > MAX_JSON:
        raise ValueError("Catalog exceeds 32 MiB")
    return json.loads(data)


def normalize(root, include_unresolved=False):
    report = {"accepted": 0, "excluded": [], "unresolved": [], "warnings": []}
    if root.get("schema") == 1:
        rows = root.get("items", [])
    elif isinstance(root.get("DATA"), dict):
        rows = []
        for url, data in root["DATA"].items():
            if not isinstance(data, dict):
                report["warnings"].append("Non-object metadata skipped")
                continue
            # Text values like "15GB" are display estimates, never exact byte lengths.
            size = data.get("size", 0)
            rows.append({
                "id": hashlib.sha256(url.encode()).hexdigest()[:24],
                "title": data.get("name") or data.get("title") or "Unnamed package",
                "category": {"game": "games", "update": "updates"}.get(data.get("type"), data.get("type", "games")),
                "size_bytes": size if type(size) is int and size > 0 else 0,
                "sha256": data.get("sha256", ""),
                "urls": [url],
                "note": "",
            })
    else:
        raise ValueError("Unsupported source catalog structure")
    items = []
    ids = set()
    for row in rows:
        title = row.get("title", "Unnamed package")
        source_url = row.get("source_url", "")
        if source_url:
            try:
                allowed(source_url)
            except (ValueError, TypeError) as e:
                report["excluded"].append({"title": title, "reason": str(e)})
                continue
        if row.get("format", "pkg") not in ("pkg", "prx"):
            report["warnings"].append(f"{title}: unsupported file format")
            continue
        good_urls, pages = [], []
        for url in row.get("urls", []):
            try:
                allowed(url)
                (pages if is_page(url) else good_urls).append(url)
            except (ValueError, TypeError) as e:
                report["excluded"].append({"title": title, "reason": str(e)})
        if pages:
            report["unresolved"].append({"title": title, "urls": pages, "reason": "Provider webpage; direct download URL not verified"})
        if not good_urls:
            if source_url:
                pass
            elif not include_unresolved or not pages:
                continue
            else:
                row = dict(row, source_url=pages[0], note="Provider page. Direct package link still needed.")
        row = dict(row, urls=good_urls)
        if not row.get("id") or row["id"] in ids:
            report["warnings"].append(f"{title}: missing or duplicate id")
            continue
        if not isinstance(row.get("title"), str) or not row["title"].strip():
            report["warnings"].append("Entry with empty title skipped")
            continue
        if type(row.get("size_bytes", 0)) is not int or not 0 <= row.get("size_bytes", 0) <= 512 * 1024**3:
            row["size_bytes"] = 0
        ids.add(row["id"])
        items.append(row)
    report["accepted"] = len(items)
    return {"schema": 1, "items": items}, report


def save_json(path, obj):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n")
    temp.replace(path)
