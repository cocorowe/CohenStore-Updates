#!/usr/bin/env python3
"""Build a small homebrew catalog from developers' own GitHub release assets."""
import argparse
from catalog_tools import load_json, save_json, allowed

PROJECTS = ["bucanero/apollo-ps4", "bucanero/PS4CheatsManager", "nueex/ps-mtp-explorer"]
CATEGORY_BY_PROJECT = {"nueex/ps-mtp-explorer": "apps"}
NOTE_BY_PROJECT = {
    "nueex/ps-mtp-explorer": "Developer release. Upstream reports testing on firmware 9.00, 10.01, and 11.00; firmware 13.52 compatibility has not been verified."
}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--output", default="catalog/catalog.json")
    args = p.parse_args()
    items = []
    for project in PROJECTS:
        release = load_json("https://api.github.com/repos/" + project + "/releases/latest")
        for asset in release.get("assets", []):
            if not asset["name"].lower().endswith(".pkg"):
                continue
            url = asset["browser_download_url"]
            allowed(url)
            digest = asset.get("digest") or ""
            items.append({
                "id": project + "/" + str(asset["id"]),
                "title": release.get("name") or project.split("/")[-1],
                "category": CATEGORY_BY_PROJECT.get(project, "homebrew"),
                "size_bytes": asset["size"],
                "sha256": digest[7:] if digest.startswith("sha256:") else "",
                "urls": [url],
                "note": NOTE_BY_PROJECT.get(project, "Developer release. Console compatibility has not been tested."),
            })
    if not items:
        raise SystemExit("No .pkg release assets found. Existing catalog kept.")
    save_json(args.output, {"schema": 1, "items": items})
    print(f"Added {len(items)} developer-hosted packages.")


if __name__ == "__main__":
    main()
