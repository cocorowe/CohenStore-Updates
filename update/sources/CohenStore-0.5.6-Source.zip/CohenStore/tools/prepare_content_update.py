#!/usr/bin/env python3
"""Prepare a deterministic, hash-described CohenStore content update bundle.

This tool does not publish updates or make the PS4 client apply them. It creates
artifacts for a future HTTPS feed and supports catalog-only content releases.
"""
import argparse, hashlib, json, re, zipfile
from pathlib import Path


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('catalog', help='Validated CohenStore schema-1 catalog JSON')
    p.add_argument('--version', required=True, help='Increasing content version, e.g. 1')
    p.add_argument('--channel', choices=('stable', 'testing'), default='testing')
    p.add_argument('--notes', default='Catalog content update')
    p.add_argument('--output', default='content-update')
    a = p.parse_args()
    if not re.fullmatch(r'[1-9][0-9]*', a.version):
        p.error('--version must be a positive integer')
    source = Path(a.catalog)
    root = json.loads(source.read_text(encoding='utf-8'))
    if root.get('schema') != 1 or not isinstance(root.get('items'), list):
        p.error('catalog must use schema 1 with an items array')
    ids = set()
    for item in root['items']:
        if not isinstance(item, dict) or not item.get('id') or not item.get('title') or not item.get('urls'):
            p.error('every item needs id, title, and at least one URL')
        if item['id'] in ids:
            p.error('duplicate catalog id: ' + str(item['id']))
        ids.add(item['id'])
        if not isinstance(item['urls'], list) or not all(isinstance(u, str) and u.startswith('https://') for u in item['urls']):
            p.error('all download URLs must be HTTPS')
    out = Path(a.output); out.mkdir(parents=True, exist_ok=True)
    catalog_out = out / 'catalog.json'
    catalog_out.write_text(json.dumps(root, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')
    manifest = {
        'schema': 1, 'channel': a.channel, 'content_version': int(a.version),
        'announcements': [a.notes],
        'catalog': {'file': 'catalog.json', 'sha256': sha256(catalog_out), 'size_bytes': catalog_out.stat().st_size},
        'app_update': None,
        'notice': 'Prepared locally. Publish only after client-side trusted manifest verification is implemented.'
    }
    (out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    bundle = out / 'cohenstore-content-update.zip'
    with zipfile.ZipFile(bundle, 'w', zipfile.ZIP_DEFLATED) as z:
        z.write(catalog_out, 'catalog.json'); z.write(out / 'manifest.json', 'manifest.json')
    print(f'Prepared {bundle} with {len(ids)} catalog entries; not published or installable by PS4 yet.')

if __name__ == '__main__': main()
