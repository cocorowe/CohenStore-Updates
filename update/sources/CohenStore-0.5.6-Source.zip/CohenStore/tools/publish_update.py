#!/usr/bin/env python3
"""Prepare a signed release. Keep the private PEM outside the public repository."""
import argparse
import hashlib
import json
from pathlib import Path
from cryptography.hazmat.primitives import serialization

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--key',required=True,type=Path)
    parser.add_argument('--package',required=True,type=Path)
    parser.add_argument('--version',required=True)
    parser.add_argument('--version-code',required=True,type=int)
    parser.add_argument('--revision',required=True,type=int)
    parser.add_argument('--url',required=True)
    parser.add_argument('--output',required=True,type=Path)
    args=parser.parse_args()
    raw=args.package.read_bytes()
    if raw[:4]!=b'\x7fCNT' or raw[0x40:0x64]!=b'IV0000-CHST00001_00-COHENSTORE000000':
        raise SystemExit('Wrong CohenStore PKG identity')
    data=dict(schema=1,channel='testing',revision=args.revision,version=args.version,
              version_code=args.version_code,title_id='CHST00001',
              content_id='IV0000-CHST00001_00-COHENSTORE000000',size_bytes=len(raw),
              sha256=hashlib.sha256(raw).hexdigest(),url=args.url)
    payload=json.dumps(data,sort_keys=True,separators=(',',':'))
    key=serialization.load_pem_private_key(args.key.read_bytes(),password=None)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(dict(signed_payload=payload,signature=key.sign(payload.encode()).hex()),indent=2)+'\n')
    print('Signed release:',args.output)

if __name__=='__main__': main()
