#!/usr/bin/env python3
"""Convert a third-party list into Cohen Store's own catalog schema."""
import argparse
from catalog_tools import load_json, normalize, save_json


def main():
    p = argparse.ArgumentParser()
    p.add_argument("source", help="Local JSON file or public URL")
    p.add_argument("output", help="Cohen Store catalog output")
    p.add_argument("--include-unresolved", action="store_true", help="Keep webpage entries labeled unresolved for review")
    p.add_argument("--report", default="catalog-import-report.json")
    args = p.parse_args()
    catalog, report = normalize(load_json(args.source), args.include_unresolved)
    save_json(args.report, report)
    if not catalog["items"]:
        raise SystemExit("No usable entries. Existing output kept. See import report.")
    save_json(args.output, catalog)
    print(f"Imported {report['accepted']} entries. Network availability has not been verified.")
    print(f"Unresolved provider pages: {len(report['unresolved'])}; excluded URLs: {len(report['excluded'])}")


if __name__ == "__main__":
    main()
