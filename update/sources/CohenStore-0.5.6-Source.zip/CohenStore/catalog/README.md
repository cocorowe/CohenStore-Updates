# Bundled catalog

The 0.5.2 repair contains 14 developer-published entries: five homebrew/fan games,
five emulators and four apps/tools. It contains download metadata, not game files.
The current feed is maintained in https://github.com/cocorowe/CohenStore-Updates.

Exact sizes and published hashes come from the developer release metadata.
Unknown hashes remain empty. Title IDs and version strings are catalog labels,
not compatibility tests. Internet Archive is excluded. Share pages cannot be
used as direct PKG downloads. See ../README.md for verification and open work.
