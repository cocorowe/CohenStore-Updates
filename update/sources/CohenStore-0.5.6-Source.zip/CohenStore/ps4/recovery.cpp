// Offline diagnostic app. Separate title ID; never changes the store queue/downloads.
#include "graphics.h"
#include <orbis/Pad.h>
#include <orbis/UserService.h>
#include <cstdio>
#include <cctype>
#include <cerrno>
#include <cstring>
#include <string>
#include <sstream>
#include <vector>
#include <sys/stat.h>
std::stringstream debugLogStream;
Scene2D::~Scene2D() {}
namespace {
const char* glyph(char ch) {
    static const char* digits[]={
        "01110100011001110101110011000101110","00100011000010000100001000010001110",
        "01110100010000100010001000100011111","11110000010000101110000010000111110",
        "00010001100101010010111110001000010","11111100001111000001000011000101110",
        "01110100001000011110100011000101110","11111000010001000100010000100001000",
        "01110100011000101110100011000101110","01110100011000101111000010000101110"};
    static const char* letters[]={
        "01110100011000111111100011000110001","11110100011000111110100011000111110",
        "01111100001000010000100001000001111","11110100011000110001100011000111110",
        "11111100001000011110100001000011111","11111100001000011110100001000010000",
        "01111100001000010111100011000101111","10001100011000111111100011000110001",
        "01110001000010000100001000010001110","00001000010000100001100011000101110",
        "10001100101010011000101001001010001","10000100001000010000100001000011111",
        "10001110111010110101100011000110001","10001110011010110011100011000110001",
        "01110100011000110001100011000101110","11110100011000111110100001000010000",
        "01110100011000110001101011001001101","11110100011000111110101001001010001",
        "01111100001000001110000010000111110","11111001000010000100001000010000100",
        "10001100011000110001100011000101110","10001100011000110001100010101000100",
        "10001100011000110101101011101110001","10001100010101000100010101000110001",
        "10001100010101000100001000010000100","11111000010001000100010001000011111"};
    ch=char(std::toupper(static_cast<unsigned char>(ch)));
    if(ch>='0' && ch<='9') return digits[ch-'0'];
    if(ch>='A' && ch<='Z') return letters[ch-'A'];
    if(ch=='-') return "00000000000000011111000000000000000";
    if(ch=='.') return "00000000000000000000000000011000110";
    if(ch==':') return "00000001100011000000001100011000000";
    if(ch=='/') return "00001000100001000100010000100010000";
    if(ch=='%') return "11001110100001000100010000101110011";
    return "00000000000000000000000000000000000";
}

void text(Scene2D& s,int x,int y,const std::string& line,int scale=3) {
    int count=0;
    for(unsigned char ch:line) {
        if(++count>94) break;
        const char* g=glyph(char(ch));
        for(int yy=0;yy<7;++yy) for(int xx=0;xx<5;++xx) if(g[yy*5+xx]=='1')
            s.DrawRectangle(x+xx*scale,y+yy*scale,scale,scale,{210,235,235});
        x+=6*scale;
    }
}
std::string tail(const char* path) {
    FILE* f=std::fopen(path,"rb");
    if(!f) return std::string("Cannot read ")+path+": "+std::strerror(errno)+"\n";
    if(std::fseek(f,0,SEEK_END)!=0) {std::fclose(f);return "Cannot seek log\n";}
    long n=std::ftell(f); if(n<0) {std::fclose(f);return "Cannot size log\n";}
    long start=n>8192?n-8192:0;std::fseek(f,start,SEEK_SET);
    char bytes[8192];size_t got=std::fread(bytes,1,sizeof(bytes),f);std::fclose(f);
    std::string out(bytes,got);for(char& c:out) if((unsigned char)c<32 && c!='\n' && c!='\t') c='?';
    return out;
}
std::vector<std::string> lines;
void report() {
    std::string result="CohenStore recovery 0.5.2\nNo store files were changed.\n\n";
    for(const char* name:{"catalog.json","queue.json","settings.json","startup.log"}) {
        const std::string path=std::string("/data/CohenStore/")+name;struct stat st;
        if(stat(path.c_str(),&st)==0) result+=std::string(name)+" bytes: "+std::to_string((long long)st.st_size)+"\n";
        else result+=std::string(name)+": "+std::strerror(errno)+"\n";
    }
    result+="\nLatest startup stages\n"+tail("/data/CohenStore/startup.log");
    result+="\nTop-level diagnostics\n"+tail("/data/CohenStore-diagnostics.txt");
    FILE* f=std::fopen("/data/CohenStore-recovery.txt","wb");
    bool saved=false;
    if(f) { saved=std::fwrite(result.data(),1,result.size(),f)==result.size();if(std::fclose(f)!=0) saved=false; }
    result=std::string(saved?"Report: /data/CohenStore-recovery.txt\n":"Could not save recovery report\n")+result;
    lines.clear();std::istringstream in(result);std::string line;
    while(std::getline(in,line)) { if(line.empty()) lines.push_back("");for(size_t i=0;i<line.size();i+=90)lines.push_back(line.substr(i,90)); }
}
}
int main() {
    Scene2D& s=*new Scene2D(1920,1080,4);
    if(!s.Init(32*1024*1024,2)) return 1;
    s.SetActiveFrameBuffer(0);
    sceUserServiceInitialize(nullptr);int user=0;sceUserServiceGetInitialUser(&user);scePadInit();int pad=scePadOpen(user,0,0,nullptr);
    report();int frame=0,top=0;uint32_t previous=0;
    for(;;) {
        OrbisPadData p={};uint32_t now=0;if(pad>=0 && scePadReadState(pad,&p)>=0) now=p.buttons;
        uint32_t pressed=now&~previous;previous=now;if(pressed&0x8) break;
        if(pressed&0x10) top=top>0?top-1:0;if(pressed&0x40 && top+18<int(lines.size())) ++top;
        if(pressed&0x4000) {report();top=0;}
        s.FrameBufferFill({12,23,32});s.DrawRectangle(0,0,1920,110,{25,80,72});
        text(s,60,36,"COHEN RECOVERY 0.5.2",5);
        for(int i=0;i<18 && top+i<int(lines.size());++i)text(s,60,151+i*44,lines[top+i]);
        text(s,60,1000,"UP/DOWN SCROLL    X RECHECK    OPTIONS EXIT",3);
        s.SubmitFlip(frame);s.FrameWait(frame);s.FrameBufferSwap();++frame;
    }
    if(pad>=0)scePadClose(pad);return 0;
}
