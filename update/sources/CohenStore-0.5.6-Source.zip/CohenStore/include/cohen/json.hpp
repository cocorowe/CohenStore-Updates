#pragma once
#include <cctype>
#include <cstdint>
#include <cstdlib>
#include <limits>
#include <map>
#include <stdexcept>
#include <string>
#include <vector>

// Small, bounded JSON reader. No third-party parser or executable catalog code.
namespace cohen {
struct Json {
    enum Kind { Null, Bool, Number, String, Array, Object } kind = Null;
    std::string text;
    std::vector<Json> array;
    std::map<std::string, Json> object;
    Json() {}
    explicit Json(const std::string& s) : kind(String), text(s) {}
    static Json obj() { Json j; j.kind = Object; return j; }
    static Json arr() { Json j; j.kind = Array; return j; }
    static Json num(uint64_t n) { Json j; j.kind = Number; j.text = std::to_string(n); return j; }
    const Json& at(const std::string& key) const {
        static const Json empty;
        auto it = object.find(key); return it == object.end() ? empty : it->second;
    }
    std::string str(const std::string& fallback = "") const { return kind == String ? text : fallback; }
    uint64_t u64(uint64_t fallback = 0) const {
        if (kind != Number || text.empty()) return fallback;
        uint64_t n = 0;
        for (char c : text) {
            if (c < '0' || c > '9' || n > (UINT64_MAX - (c - '0')) / 10) return fallback;
            n = n * 10 + c - '0';
        }
        return n;
    }
    std::string dump() const;
    static Json parse(const std::string& s);
};
inline std::string quoted(const std::string& s) {
    static const char* hex = "0123456789abcdef";
    std::string out = "\"";
    for (unsigned char c : s) {
        if (c == '"' || c == '\\') { out += '\\'; out += char(c); }
        else if (c < 32) { out += "\\u00"; out += hex[c >> 4]; out += hex[c & 15]; }
        else out += char(c);
    }
    return out + "\"";
}
inline std::string Json::dump() const {
    if (kind == String) return quoted(text);
    if (kind == Number || kind == Bool) return text;
    if (kind == Null) return "null";
    std::string out = kind == Array ? "[" : "{"; bool first = true;
    if (kind == Array) for (const auto& v : array) {
        if (!first) out += ',';
        first = false; out += v.dump();
    }
    if (kind == Object) for (const auto& v : object) {
        if (!first) out += ',';
        first = false; out += quoted(v.first) + ":" + v.second.dump();
    }
    return out + (kind == Array ? "]" : "}");
}
class JsonReader {
    const std::string& s; size_t p = 0, nodes = 0;
    void ws() { while (p < s.size() && std::isspace(static_cast<unsigned char>(s[p]))) ++p; }
    bool take(char c) { ws(); if (p < s.size() && s[p] == c) { ++p; return true; } return false; }
    [[noreturn]] void fail() { throw std::runtime_error("Invalid JSON near byte " + std::to_string(p)); }
    uint32_t hex4() {
        uint32_t n = 0;
        for (int i = 0; i < 4; ++i) {
            if (p == s.size()) fail();
            char c = s[p++]; int d = c >= '0' && c <= '9' ? c-'0' : c >= 'a' && c <= 'f' ? c-'a'+10 : c >= 'A' && c <= 'F' ? c-'A'+10 : -1;
            if (d < 0) fail();
            n = n * 16 + unsigned(d);
        }
        return n;
    }
    static void utf8(std::string& t, uint32_t cp) {
        if (cp < 0x80) t += char(cp);
        else if (cp < 0x800) { t += char(0xc0 | (cp >> 6)); t += char(0x80 | (cp & 63)); }
        else if (cp < 0x10000) { t += char(0xe0 | (cp >> 12)); t += char(0x80 | ((cp >> 6)&63)); t += char(0x80 | (cp & 63)); }
        else { t += char(0xf0 | (cp >> 18)); t += char(0x80 | ((cp >> 12)&63)); t += char(0x80 | ((cp >> 6)&63)); t += char(0x80 | (cp&63)); }
    }
    std::string string() {
        if (!take('"')) fail();
        std::string t;
        while (p < s.size()) {
            unsigned char c = s[p++];
            if (c == '"') return t;
            if (c < 32) fail();
            if (c != '\\') { t += char(c); continue; }
            if (p == s.size()) fail();
            c = s[p++];
            if (c == '"' || c == '\\' || c == '/') t += char(c);
            else if (c == 'b') t += '\b';
            else if (c == 'f') t += '\f';
            else if (c == 'n') t += '\n';
            else if (c == 'r') t += '\r';
            else if (c == 't') t += '\t';
            else if (c == 'u') {
                uint32_t cp = hex4();
                if (cp >= 0xd800 && cp <= 0xdbff) {
                    if (p+2 > s.size() || s.substr(p,2) != "\\u") fail();
                    p += 2; uint32_t low = hex4();
                    if (low < 0xdc00 || low > 0xdfff) fail();
                    cp = 0x10000 + ((cp-0xd800)<<10) + low-0xdc00;
                } else if (cp >= 0xdc00 && cp <= 0xdfff) fail();
                utf8(t,cp);
            } else fail();
        }
        fail();
    }
    Json value(unsigned depth) {
        if (depth > 40 || ++nodes > 300000) fail();
        ws(); if (p == s.size()) fail(); Json j;
        if (s[p] == '"') return Json(string());
        if (take('{')) {
            j = Json::obj(); if (take('}')) return j;
            do { std::string k = string(); if (!take(':')) fail();
                Json v = value(depth+1);
                if (!j.object.emplace(k,v).second) fail();
            } while (take(','));
            if (!take('}')) fail();
            return j;
        }
        if (take('[')) {
            j = Json::arr(); if (take(']')) return j;
            do { j.array.push_back(value(depth+1)); } while (take(','));
            if (!take(']')) fail();
            return j;
        }
        for (const char* literal : {"true", "false", "null"}) {
            std::string t(literal);
            if (s.compare(p,t.size(),t) == 0) { p += t.size(); j.kind = t == "null" ? Json::Null : Json::Bool; j.text = t; return j; }
        }
        size_t start = p;
        if (s[p] == '-') ++p;
        if (p == s.size() || !std::isdigit(static_cast<unsigned char>(s[p]))) fail();
        if (s[p] == '0') ++p;
        else while (p < s.size() && std::isdigit(static_cast<unsigned char>(s[p]))) ++p;
        if (p < s.size() && s[p] == '.') {
            ++p; size_t a = p;
            while (p < s.size() && std::isdigit(static_cast<unsigned char>(s[p]))) ++p;
            if (a == p) fail();
        }
        if (p < s.size() && (s[p] == 'e' || s[p] == 'E')) {
            ++p; if (p < s.size() && (s[p] == '+' || s[p] == '-')) ++p;
            size_t a = p;
            while (p < s.size() && std::isdigit(static_cast<unsigned char>(s[p]))) ++p;
            if (a == p) fail();
        }
        j.kind = Json::Number; j.text = s.substr(start,p-start); return j;
    }
public:
    explicit JsonReader(const std::string& t) : s(t) {}
    Json read() { if (s.size() > 32*1024*1024) fail(); Json j = value(0); ws(); if (p != s.size()) fail(); return j; }
};
inline Json Json::parse(const std::string& s) { return JsonReader(s).read(); }
}
