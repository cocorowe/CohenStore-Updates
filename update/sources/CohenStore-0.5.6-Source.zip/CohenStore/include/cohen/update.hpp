#pragma once
#include "store.hpp"
namespace cohen {
constexpr uint64_t APP_VERSION_CODE=56;
constexpr const char* APP_VERSION="0.5.6";
constexpr const char* UPDATE_URL="https://raw.githubusercontent.com/cocorowe/CohenStore-Updates/main/update/release.json";
struct AppUpdate { uint64_t revision=0, version_code=0; std::string version; Item package; };
AppUpdate verify_update(const std::string& envelope,uint64_t minimum_revision);
void verify_update_package(const AppUpdate&,const std::string& path,Cancel cancel=[] {return false;});
std::string stage_update_package(const AppUpdate&,const std::string& source,const std::string& directory,Cancel cancel=[] {return false;});
}
