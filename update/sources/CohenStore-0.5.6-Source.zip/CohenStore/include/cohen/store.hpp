#pragma once
#include "json.hpp"
#include <functional>
#include <memory>
#include <string>
#include <vector>

namespace cohen {
struct Item {
    std::string id, title, category = "games", sha256, note;
    std::string format = "pkg", game, source_url, compatibility;
    std::string app_version, parent_title_id, region, min_firmware;
    std::vector<std::string> game_versions, title_ids;
    uint64_t size = 0; // Exact bytes only. Zero means unknown, never an estimate.
    std::vector<std::string> urls;
    Json json() const;
    static Item from(const Json&);
    bool downloadable() const { return !urls.empty(); }
};
struct Catalog { std::vector<Item> items; std::vector<std::string> warnings; };
Catalog catalog_read(const std::string&);
std::string read_file(const std::string&, size_t limit = 32*1024*1024);
void write_atomic(const std::string&, const std::string&);
std::string lower(std::string);
struct Url { std::string scheme, host, authority, path; };
Url parse_url(const std::string&);
void allow_url(const std::string&); // Excludes archive.org and its subdomains.
std::string resolve_url(const std::string& base, const std::string& location);
bool provider_page(const std::string&);
std::string sha256_file(const std::string&, std::function<bool()> cancel = [] { return false; });
std::string item_key(const Item&);

struct Response {
    int status = 0;
    std::map<std::string,std::string> headers;
    std::string get(const std::string& k) const {
        auto i = headers.find(lower(k)); return i == headers.end() ? "" : i->second;
    }
};
using Cancel = std::function<bool()>;
using Headers = std::function<bool(const Response&)>;
using Body = std::function<bool(const char*, size_t)>;
class Transport {
public:
    virtual ~Transport() {}
    // One HTTP request only. The engine validates/follows every redirect.
    virtual std::string get(const std::string&, const std::map<std::string,std::string>&, Headers, Body, Cancel) = 0;
};
std::unique_ptr<Transport> make_transport();
struct Progress { uint64_t done = 0, total = 0; unsigned attempt = 0; std::string message; };
struct Result { bool ok = false, paused = false; std::string path, error; uint64_t bytes = 0; };
struct Options {
    unsigned retries = 4, retry_delay_ms = 1000;
    uint64_t reserve_bytes = 32*1024*1024;
};
class Engine {
    Transport& transport_;
public:
    explicit Engine(Transport& t) : transport_(t) {}
    Result download(const Item&, const std::string& directory,
                    std::function<void(const Progress&)> progress = {},
                    Cancel cancel = [] { return false; }, const Options& options = Options());
    std::string fetch_text(const std::string& url, Cancel cancel = [] { return false; });
};
struct Job { Item item; std::string state = "queued", message; };
// Queue snapshots are atomic. Interrupted jobs reopen paused, never silently erased.
std::vector<Job> load_queue(const std::string&);
void save_queue(const std::string&, const std::vector<Job>&);
}
