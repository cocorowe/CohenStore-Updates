#pragma once
#include "store.hpp"
#include <map>
#include <cstdint>
namespace cohen { namespace ui {
using Ink=uint32_t;
struct Glyph { int width=0,height=0,advance=0; std::vector<unsigned char> alpha; };
struct Cover { int width=0,height=0; std::vector<unsigned char> rgb; };
class Canvas {
    std::map<int,std::map<int,Glyph>> fonts_;
    std::map<std::string,Cover> covers_;
public:
    static const int width=1920,height=1080;
    std::vector<uint32_t> pixels;
    Canvas() : pixels(width*height) {}
    void load_cover(const std::string& key,const std::string& path);
    bool cover(const std::string& key,int x,int y,int w,int h);
    void load_fonts(const std::string&);
    void pixel(int,int,Ink);
    void rect(int,int,int,int,Ink);
    void rounded(int,int,int,int,int,Ink);
    void gradient(int,int,int,int,Ink,Ink);
    void line(int,int,int,int,int,Ink);
    void circle(int,int,int,Ink);
    int measure(const std::string&,int) const;
    void text(int,int,const std::string&,int,Ink,int max_width=1900);
    void wrap(int,int,const std::string&,int,Ink,int max_width,int lines=3);
    void save_ppm(const std::string&) const;
};
struct View {
    Catalog catalog; std::vector<Job> jobs;
    Progress progress;
    std::string category="all",query,status,version_filter="1.56";
    int selected=0,active=-1,key=0,theme=0,setting_index=0;
    std::vector<std::string> setting_values;
    bool queue=false,keyboard=false,network_ready=false;
};
const std::vector<std::string>& categories();
std::vector<size_t> visible(const View&);
std::string category_title(const std::string&);
void render(Canvas&,const View&);
}}
