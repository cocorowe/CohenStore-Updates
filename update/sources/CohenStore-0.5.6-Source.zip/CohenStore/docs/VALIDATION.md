# Validation for 0.5.2 repair test

Recorded October 30, 2026. See README.md for the current status and limits.

- 57 app tests passed, including native frontend boot/navigation, corrupted
  queue preservation, offline first launch, native HTTP ABI arguments, cleanup,
  response-size bounds and download receipt write failures.
- 11 feed tests passed. All 14 live entries passed small range/header probes.
- Two full desktop game downloads completed; 2048 matched its publisher digest.
- Both native installers compiled, linked, generated FSELF and passed package
  digest/signature validation. The SFO entries extracted from both packages
  match the expected separate title IDs and APP_VER 00.08.
- Re-extracted repair catalog/font/art files match the source assets.

Evidence: tests-052.log, native-repair-052.log, native-recovery-052.log,
package-check-052.json, link-check-052.json and real-downloads-052.json.

These checks do not execute PS4 graphics, kernel, networking, TLS or installation.
0.5.2 is not confirmed to launch on the user's console. The actual crash log is
still needed if the repair does not launch.
