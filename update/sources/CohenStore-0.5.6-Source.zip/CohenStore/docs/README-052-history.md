# CohenStore 0.5.2 repair test

A native PS4 mint storefront with section navigation, item details, favorites,
search, a persistent download queue, retries, safe Range/ETag resume and SHA-256
receipts. Intended target: PS4 13.52 / GoldHEN v2.4b18.12. This new build still
requires console testing. 0.4.1 launched for the user; 0.5.1 crashed.

## Repair changes

- Explicitly select frame buffer zero before drawing. The SDK sample constructor
  previously left this index indeterminate. The private graphics helper also
  initializes/checks its frame-buffer fields. This is a real crash bug found by
  inspection, but without the console log it is not proof of the user's cause.
- Use 32 MiB of display memory for the two 1080p buffers, down from 192 MiB.
- Present the first frame before starting the download worker. First repair
  launch disables automatic network activity and backs up existing settings to
  settings.before-052.json. R3 refresh and X download remain available.
- Load networking by internal system-module IDs, including NetCtl. Use corrected
  ABI import aliases for HTTP controls and SSL cleanup. Remove process module
  enumeration and hard-coded SPRX file loading from the HTTP adapter.
- Keep a failed network initialization from retrying indefinitely. Show the
  failure and allow a deliberate later retry.
- Fall back to the bundled catalog when the cached catalog is invalid. Preserve
  a damaged queue and disable new downloads until it is recovered.
- Write bounded startup stages to /data/CohenStore-diagnostics.txt as well as
  /data/CohenStore/startup.log.
- Save a download receipt before publishing the completed filename. A receipt
  write failure leaves a retryable partial download instead of an orphan final.

## Installers

- dist/CohenStore-0.5.2-REPAIR-TEST.pkg updates the existing Cohen Store,
  title ID CHST00001. Install over the existing app with it closed.
- dist/CohenStore-Recovery-0.5.2.pkg is a separate offline Cohen Recovery app,
  title ID CHST00002. It reads a few fixed store files, displays the last startup
  stages, and exports /data/CohenStore-recovery.txt. It does not change the
  store's catalog, settings, queue or downloaded games. X rechecks, Up/Down
  scrolls, Options exits.

Both packages use PS4 APP_VER 00.08. The product/build label is 0.5.2.
Keep the previous installer available. Console launch, native network and
installation behavior remain unverified until tested on the PS4.

## Catalog and controls

The bundle contains 14 entries: five homebrew/fan games, five emulators and four
apps/tools. It contains listings, not the full game files. Two publisher cover
images and the font atlas are bundled; other tiles use fallback art.

Live feed: https://raw.githubusercontent.com/cocorowe/CohenStore-Updates/main/catalog/catalog.json
Maintenance: https://github.com/cocorowe/CohenStore-Updates

Games, Updates, DLC, Homebrew, Apps, Emulators, Mod menus, Favorites, History,
Downloads, Settings and Catalog feed have their own views. Updates/DLC/menu
views remain empty until actual compatible packages are supplied.

D-pad moves cards; L1/R1 changes sections; X queues/retries; L3 favorites;
Square opens Downloads; Triangle searches; Circle pauses; R2 filters menus;
R3 refreshes the catalog; Options exits. Settings offers optional startup and
15-minute catalog checks. It does not update the store application binary.

## Verification

57 app tests and 11 feed tests pass. Tests exercise the actual native frontend
and HTTP adapter with simulated PS4 APIs, checked vectors, and address/undefined
behavior sanitizers for the adapter. LeakSanitizer cannot run in this host
sandbox and is disabled; resource cleanup is checked explicitly.

Native build, FSELF generation and package validation pass for both installers.
Both package identities were extracted and checked. The repair package's
catalog, fonts and both cover files match their source assets after extraction.

All 14 links passed four-byte header/advertised-size checks. Full desktop
transfers of 2048 (35,454,976 bytes) and Relic Hunters Zero (71,696,384 bytes)
completed. 2048 matches its published SHA-256; Relic Hunters Zero has no published
hash to compare. These are desktop results, not PS4 tests or reliability promises.

The feed now has daily publisher metadata maintenance and daily download link
checks, with reports retained in GitHub Actions. Internet Archive is excluded.

## Still needs external input or PS4 hardware

- Launch and navigate the repaired store, press R3, then test 2048 download,
  pause/resume, app restart and manual installation on the PS4.
- If launch still fails, send /data/CohenStore-diagnostics.txt, the Recovery
  report, or a photo of Recovery's last stages and the PS4 error code.
- Commercial games, game updates and DLC need working direct package sources
  with correct title IDs, versions and base-game relationships. Sources checked
  so far are mostly share pages, Archive links or expired direct links.
- A future custom menu needs its PRX/PKG and supported GTA version/title IDs.

Automatic package installation, signed application updates, arbitrary remote
artwork/screenshots, plugin activation/switching and combined mod menus are
not implemented. Downloads currently install through Package Manager.

## Build and license

Use OpenOrbis 0.5.4 and LLVM 18.1.8. tools/build_ps4.py accepts --sdk and
--compiler-bin; add --recovery for the separate diagnostic app. Builds are
sequential because they reuse a private SDK sample build directory. SDK binaries
are external and are not included. See docs/BUILD.md for host dependencies.

make test runs app checks. make build/cohen-preview builds the desktop renderer.
Source is GPL-3.0-or-later. Font/art licenses and attribution are under assets/.
The 0.4.1 repair notes and earlier mint check files are historical evidence.
