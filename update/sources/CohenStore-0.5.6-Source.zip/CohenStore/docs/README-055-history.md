# CohenStore 0.5.5 UPDATER TEST

The Store Updates page now checks signed releases and stages verified PKGs in `/data/pkg`. Install this build once by USB, then use R3 to check and X to download newer versions. Close the app before installing with GoldHEN. Console behavior still needs testing. See [updater instructions](docs/STORE_UPDATES.md).

# CohenStore 0.5.4 header-limit test

The user confirmed 0.5.3 launches without the previous crash. Catalog refresh
works. Downloads return 0x80431073 (response headers exceed the native library
limit). This update sets sceHttpSetResponseHeaderMaxSize(template, 65536) before
creating/sending requests. The adapter uses the PS4 ABI (int ID, 64-bit size).

The native adapter tests refuse to send without that setting, alongside the
existing constrained-stack and cleanup checks. All 58 app tests pass. Native
build and PKG validation pass. PS4 download completion is still pending.

Install dist/CohenStore-0.5.4-HEADER-TEST.pkg over the closed store. Product label:
Mint test 0.5.4. PS4 APP_VER 00.10; title ID CHST00001. Retry 2048 from Downloads
or queue it from Games. Keep Recovery 0.5.2; it reads this build's HTTP stages.

R3 refreshes the catalog; Square opens Downloads. No mapping change was needed
after the user clarified that R3 does refresh. The feed still contains 14
entries, so a refresh need not add titles. No certificate checks were disabled.
Earlier stack, offline-startup and persistence repairs remain. Commercial-game,
update/DLC sources, automatic installation and store-app updates are unfinished.
See historical readmes in docs for earlier verification and limits.
