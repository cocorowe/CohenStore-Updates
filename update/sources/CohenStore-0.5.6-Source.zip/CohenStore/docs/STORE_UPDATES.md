# CohenStore 0.5.6 app updater

Install the 0.5.5 UPDATER-TEST PKG once through USB to add the updater.
Open Store Updates with L1/R1. R3 checks the official signed release.
X checks when no newer release is known, or downloads a newer release after a check.
R2 refreshes the content catalog. Circle pauses an update download.

The update is verified and moved into `/data/pkg/CohenStore-VERSION_CODE.pkg`.
Close CohenStore and use GoldHEN Package Installer with its source set to `/data/pkg`.
The app does not replace itself while running or install packages automatically.

## Release format and trust

`update/release.json` contains an exact `signed_payload` string and a lowercase
Ed25519 `signature` in hex. The embedded public key verifies the exact UTF-8
payload bytes before parsing them. Monocypher 4.0.2 provides the standard
Ed25519 implementation, including its optional SHA-512 Ed25519 module.

The payload includes schema 1, testing channel, positive revision, version code,
version label, CHST00001, fixed content ID, exact package size, SHA-256 and
an official repository HTTPS URL. A lower revision or version than installed
is rejected. The highest accepted revision is saved atomically. Package bytes
must match the signed size and SHA-256, have PS4 PKG magic, and contain the
CohenStore content ID at the expected header offset before staging.

The feed points at 0.5.6. An installed 0.5.5 should offer 0.5.6; an installed
0.5.6 should report up to date. The staged update filename is CohenStore-56.pkg. First-install signature trust comes from
the installed PKG. Deleting local revision state removes remembered revision
protection, but does not remove the embedded key or installed version floor.

## Publishing future updates

Keep the private PEM backup outside public source and GitHub. Never put it on
PS4. Keep the existing public key in future clients. Build the next package
with an increased APP_VERSION_CODE and APP_VER. Upload the PKG to the official
repository and use `tools/publish_update.py` with the private key, exact package,
version, version code, strictly increasing revision, immutable HTTPS package URL,
and output `update/release.json`. Python signing requires `cryptography`.

The native PKG compiles and validates on the build machine. A real PS4 still
needs to verify HTTPS, controller actions, download, and GoldHEN installation.
Keep the known working PKG for recovery.
