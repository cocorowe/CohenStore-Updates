> Historical roadmap, not a completion report. See README.md for current status.

# CohenStore 1.0 feature scope and acceptance checklist

This document turns the requested ten enhancements into testable work items. It is a plan/checklist, not a claim that the PS4 frontend already implements them.

## Storefront features

1. **Featured Games** — curated featured carousel; every entry resolves to a catalog ID and has an artwork fallback.
2. **Most Downloaded** — rank from opt-in, privacy-preserving aggregate download counts; until a backend exists, show an explicitly labelled curated/popular list rather than fabricated counts.
3. **What's New** — content-feed announcements with version/date and links to changed catalog entries.
4. **Wishlist** — persistent local favorites keyed by stable catalog ID; tolerate removed catalog entries.
5. **Download manager** — queue, progress, pause/resume, retry, completed/failed states, and download history. Existing engine/queue is the base; console UI and edge-case testing remain.
6. **Compatibility checker** — display known firmware range, CUSA/title ID, game version and payload type only when supplied by a verified catalog record; unknown values must say unknown.
7. **Recently Viewed** — persist a bounded list of catalog IDs and update it when an item detail page is opened.
8. **Notifications** — opt-in notices for completed downloads and verified content-feed updates; no silent package installation.
9. **Game details** — artwork, description, category, version, CUSA/title ID, exact size, hash, compatibility and source status; omit unknown fields rather than invent them.
10. **Store Update History** — retain content version, release notes, timestamp and changed item IDs from the trusted feed.

## Required catalog metadata (optional fields)

Catalog item records may add `description`, `artwork_url`, `cusa`, `game_version`, `firmware_min`, `firmware_max`, `payload_type` (`pkg`, `plugin`, `archive`, or `other`), `source_status`, `featured`, and `release_date`. Unknown metadata must remain absent/unknown. Artwork and metadata URLs must use HTTPS. Never list commercial game PKGs unless distribution is authorized; catalog listings do not grant distribution rights.

## Release gates

- [ ] Native UI implements and persists wishlist, recently viewed, detail pages, filters and history.
- [ ] Featured/popular/What's New pages use real curated or measured data and label the source.
- [ ] Compatibility fields are validated and never guessed.
- [ ] Update feed uses HTTPS plus a trusted signature (hash alone is not publisher authentication).
- [ ] Content updates apply atomically with rollback and monotonic version checks.
- [ ] App updates require explicit user confirmation and verified package hash/signature.
- [ ] Build against the actual OpenOrbis SDK and test launch, input, TLS, storage and downloads on the target PS4/firmware.
- [ ] Keep the previous known-good PKG until the replacement passes console testing.

## Update preparation tool

`tools/prepare_content_update.py` validates a schema-1 catalog, writes a versioned manifest with a SHA-256 digest, and packages the catalog plus manifest. This is a maintainer-side preparation tool only: it does not host/publish the feed, sign the manifest, or make the current PS4 app apply updates.

## Current implementation snapshot (0.4 native source)

- [x] Persistent local Favorites/Wishlist storage and a Favorites category.
- [x] Completed-download history view backed by the persistent queue records.
- [x] Category navigation includes a Mod Menus placeholder category.
- [x] Search, queue display, retry of paused/failed jobs, and theme/settings persistence.
- [x] Native source compiles and links with the supplied OpenOrbis SDK; the PKG
      passes the SDK's package validation and contains the bundled catalog.
- [ ] Recently Viewed, artwork, item details, notifications, featured/popular,
      What's New, and Store Update History remain unimplemented.
- [ ] Games, Updates, DLC, Emulators, and Mod Menus categories need verified
      records; the bundled catalog currently has only three homebrew/app entries.
- [ ] Native console launch, networking, TLS, controller behavior, and download
      testing remain required before calling the app stable.
