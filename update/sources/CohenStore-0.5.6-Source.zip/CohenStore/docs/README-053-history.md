# CohenStore 0.5.3 request test

This test follows the user's 0.5.2 Recovery photos. They show successful network
initialization followed by Catalog request started, with no completion. A later
launch reaches the UI worker without another request. The photos do not identify
the individual failing HTTP call.

Changes:
- Move the 64 KiB request buffer from the stack to the heap.
- Give the native download worker an explicit 2 MiB stack via scePthread attrs.
- Log each HTTP step to /data/CohenStore-diagnostics.txt.
- Read download file sizes through 64-bit file seek/tell rather than relying on
  the questionable native stat size field shown in Recovery.

A local simulated 64 KiB worker stack reproduces a stack-overflow with the old
buffer. The revised adapter passes that constrained-stack test. This is evidence
of a stack risk, not a measurement of PS4's actual default stack or confirmation
that every console crash has this cause.

58 app tests pass. The native main app compiles and the generated PKG passes
integrity validation. The new native stack setup compiles against the SDK but
still requires console verification. No TLS certificate checks are disabled.

Install dist/CohenStore-0.5.3-REQUEST-TEST.pkg over the closed Cohen Store.
Product label: Mint test 0.5.3. PS4 APP_VER: 00.09. Title ID: CHST00001.
Press R3 once and wait for either the catalog status or an error.
If it crashes, keep using the already-installed Recovery 0.5.2: the last
HTTP: line in its top-level diagnostics will narrow the failing step.
The existing Recovery app does not need replacing.

The 14-entry catalog and offline-startup behavior remain. Commercial-game,
update/DLC sources and automatic installation/app updates remain unfinished.
See docs/README-052-history.md for the earlier features and limitations.
SDK binaries and game packages are not part of this source archive.
