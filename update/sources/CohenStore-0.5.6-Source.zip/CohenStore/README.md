# CohenStore 0.5.6 UPDATER TEST

0.5.5 has been confirmed to open and check the update feed on the user’s PS4.
0.5.6 is the first test of downloading a newer store build without USB.

In Store Updates, press R3 and then X. Once verification finishes, close the
store and use GoldHEN Package Installer with its source set to /data/pkg.
The downloaded update is CohenStore-56.pkg. After installation the footer
should show 0.5.6 and a new update check should report up to date.

This build also fixes retries using stale catalog links. After refreshing the
catalog, retrying a paused or failed job uses the current item’s URLs, size and
hash. Native HTTP failures now identify the failing host without exposing URL
tokens. The 64 KiB response-header fix from 0.5.4 is retained. Certificate
checks remain enabled.

For a game download test, go to Games, press R3, select 2048 v1.0 and press X.
If an old failed entry exists, press Square and retry it with X. Completed games
are saved under /data/CohenStore/downloads and are installed manually.

Validation: 74 desktop tests pass, including actual native UI retries with
stale saved links. The native executable compiles and the PKG passes its hash
and signature checks. PS4 update download, installation, and game download
completion remain console tests. Build success is not proof of console success.

See docs/STORE_UPDATES.md and docs/BUILD.md. Prior readmes are retained in docs.
