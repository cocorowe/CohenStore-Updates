import hashlib
import http.server
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import tempfile
import threading
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]
CLIENT = ROOT / "build/cohen-store"
# Synthetic test data, deliberately not an installable game.
DATA = b"\x7fCNT" + bytes(range(256)) * 2048
OTHER = b"\x7fCNT" + b"Z" * (len(DATA) - 4)
PRX = b"\x4f\x15\x3d\x1d" + DATA[4:]
ELF = b"\x7fELF" + DATA[4:]
STATE = {}


class Handler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):
        pass

    def do_GET(self):
        name = self.path.split("?")[0]
        state = STATE.setdefault(name, {"count": 0, "ranges": [], "if_range": []})
        state["count"] += 1
        start = int(self.headers.get("Range", "bytes=0-").split("=")[1].split("-")[0])
        state["ranges"].append(start)
        state["if_range"].append(self.headers.get("If-Range"))
        if name == "/huge":
            self.send_response(200)
            self.send_header("Content-Length", str(512*1024**3))
            self.end_headers()
            self.close_connection = True
            return
        if name == "/archive-redirect":
            self.send_response(302)
            self.send_header("Location", "https://archive.org/example.pkg")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if name == "/redirect":
            self.send_response(302)
            self.send_header("Location", "/ok")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if name == "/retry" and state["count"] == 1:
            self.send_response(503)
            self.send_header("Retry-After", "0")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if name == "/denied":
            self.send_response(403)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        if name == "/html":
            data = b"<html>Download button, not a package</html>"
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        data = PRX if name == "/prx" else ELF if name == "/elf" else OTHER if name in ("/changed", "/etag-lie") and state["count"] > 1 else DATA
        etag = '"changed"' if data is OTHER else '"fixture-v1"'
        ranged = bool(start)
        if name in ("/ignore-range", "/changed", "/no-etag"):
            ranged = False
        if name == "/bad-range" and ranged:
            start += 1
        payload = data[start:] if ranged else data
        self.send_response(206 if ranged else 200)
        self.send_header("Content-Type", "application/octet-stream")
        if name != "/no-length":
            self.send_header("Content-Length", str(len(payload)))
        else:
            self.send_header("Connection", "close")
            self.close_connection = True
        if name != "/no-etag":
            self.send_header("ETag", etag)
        if ranged:
            self.send_header("Content-Range", f"bytes {start}-{len(data)-1}/{len(data)}")
        self.end_headers()
        cut = name in ("/cut", "/ignore-range", "/changed", "/no-etag", "/bad-range", "/etag-lie") and state["count"] == 1
        slow = name == "/slow"
        try:
            if cut:
                self.wfile.write(payload[:65536])
                self.wfile.flush()
                self.connection.shutdown(socket.SHUT_RDWR)
                self.close_connection = True
                return
            for n in range(0, len(payload), 4096):
                self.wfile.write(payload[n:n+4096])
                if slow:
                    self.wfile.flush()
                    time.sleep(0.015)
        except (BrokenPipeError, ConnectionResetError):
            pass


class DownloadTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        class QuietServer(http.server.ThreadingHTTPServer):
            def handle_error(self, request, client_address):
                # Early rejection deliberately resets some fixture connections.
                pass
        cls.server = QuietServer(("127.0.0.1", 0), Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()
        cls.url = f"http://127.0.0.1:{cls.server.server_port}"

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def setUp(self):
        STATE.clear()
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def catalog(self, endpoint, **kw):
        item = {"id": "test", "title": "Synthetic test package", "urls": [self.url + endpoint]}
        item.update(kw)
        p = self.path / "catalog.json"
        p.write_text(json.dumps({"schema": 1, "items": [item]}))
        return p

    def run_download(self, endpoint, retries=3, expected=True, **kw):
        cat = self.catalog(endpoint, **kw)
        p = subprocess.run([str(CLIENT), "download", str(cat), "test", str(self.path / "dl"), str(retries), "0"], text=True, capture_output=True, timeout=12)
        self.assertEqual(p.returncode, 0 if expected else 1, p.stderr + p.stdout)
        r = json.loads(p.stdout)
        self.assertEqual(r["ok"], expected)
        return r

    def check_payload(self, r, expected=DATA):
        path = Path(r["path"])
        self.assertEqual(path.read_bytes(), expected)
        receipt = json.loads(Path(str(path)+".json").read_text())
        self.assertEqual(receipt["sha256"], hashlib.sha256(expected).hexdigest())
        self.assertFalse(list(path.parent.glob("*.part")))

    def test_normal_download_and_receipt(self):
        self.check_payload(self.run_download("/ok"))

    def test_receipt_write_failure_does_not_publish_unrecoverable_final_file(self):
        # A directory at the receipt path prevents its atomic rename even as root.
        directory=self.path/'dl';directory.mkdir()
        # Compute the same stable public ID key instead of relying on a filename.
        value=14695981039346656037
        for byte in b'test': value=((value^byte)*1099511628211)&((1<<64)-1)
        receipt=directory/(format(value,'016x')+'.pkg.json')
        if not receipt.exists():receipt.mkdir()
        result=self.run_download('/ok',expected=False)
        self.assertIn('Cannot save',result['error'])
        self.assertEqual(list(directory.glob('*.pkg')),[])
        self.assertEqual(len(list(directory.glob('*.pkg.part'))),1)

    def test_prx_download_keeps_plugin_extension_and_receipt(self):
        result = self.run_download("/prx", format="prx")
        self.assertEqual(Path(result["path"]).suffix, ".prx")
        self.check_payload(result, PRX)

    def test_elf_prefix_supported_for_prx(self):
        self.check_payload(self.run_download("/elf", format="prx"), ELF)

    def test_pkg_cannot_be_mislabeled_as_prx(self):
        result = self.run_download("/ok", format="prx", expected=False)
        self.assertIn("format", result["error"])
        self.assertFalse(list((self.path/"dl").glob("*.prx")))

    def test_creator_reference_cannot_start_network_download(self):
        result = self.run_download("/ok", urls=[], source_url="https://creator.example/menu", expected=False)
        self.assertIn("Creator reference", result["error"])
        self.assertEqual(STATE, {})

    def test_plugin_metadata_survives_saved_queue(self):
        item = {"id":"menu156", "title":"Fixture menu", "format":"prx", "category":"menus",
                "game":"GTA V", "game_versions":["1.56"], "title_ids":["CUSA00419"],
                "compatibility":"Creator listed", "source_url":"https://creator.example/menu",
                "urls":[self.url+"/prx"]}
        queue = self.path/"queue.json"
        queue.write_text(json.dumps({"schema":1,"jobs":[{"item":item,"state":"paused"}]}))
        subprocess.run([str(CLIENT),"queue-check",str(queue)],check=True,capture_output=True)
        saved = json.loads(Path(str(queue)+".checked").read_text())["jobs"][0]["item"]
        for key in ("format","game","game_versions","title_ids","compatibility","source_url"):
            self.assertEqual(saved[key],item[key])

    def test_connection_cut_resumes_at_actual_byte_count(self):
        r = self.run_download("/cut")
        self.check_payload(r)
        self.assertEqual(STATE["/cut"]["ranges"], [0, 65536])
        self.assertEqual(STATE["/cut"]["if_range"][1], '"fixture-v1"')

    def test_server_ignores_range_restarts_without_appending(self):
        self.check_payload(self.run_download("/ignore-range"))
        self.assertEqual(STATE["/ignore-range"]["ranges"], [0, 65536])

    def test_changed_file_200_restarts(self):
        self.check_payload(self.run_download("/changed"), OTHER)

    def test_changed_file_206_is_not_appended(self):
        r = self.run_download("/etag-lie", expected=False)
        self.assertIn("changed", r["error"])
        self.assertEqual(next((self.path/"dl").glob("*.part")).stat().st_size, 65536)

    def test_missing_etag_restarts_safely(self):
        self.check_payload(self.run_download("/no-etag"))
        self.assertEqual(STATE["/no-etag"]["ranges"], [0, 0])

    def test_bad_content_range_is_refused(self):
        r = self.run_download("/bad-range", expected=False)
        self.assertIn("invalid resume range", r["error"])

    def test_retry_temporary_server_error(self):
        self.check_payload(self.run_download("/retry"))
        self.assertEqual(STATE["/retry"]["count"], 2)

    def test_mirror_change_does_not_mix_partial_files(self):
        r = self.run_download("/cut", retries=0, urls=[self.url+"/cut", self.url+"/ok"])
        self.check_payload(r)
        self.assertEqual(STATE["/ok"]["ranges"], [0])

    def test_storage_precheck(self):
        r = self.run_download("/huge", expected=False)
        self.assertIn("free storage", r["error"])
        self.assertFalse(list((self.path/"dl").glob("*.part")))

    def test_unknown_transfer_length_uses_exact_catalog_size(self):
        self.check_payload(self.run_download("/no-length", size_bytes=len(DATA)))

    def test_unknown_transfer_length_without_catalog_size_is_refused(self):
        r = self.run_download("/no-length", expected=False)
        self.assertIn("size", r["error"])

    def test_html_is_not_saved_as_pkg(self):
        r = self.run_download("/html", expected=False)
        self.assertIn("webpage", r["error"])
        self.assertFalse(list((self.path/"dl").glob("*.pkg")))

    def test_denied_does_not_keep_retrying(self):
        self.run_download("/denied", expected=False)
        self.assertEqual(STATE["/denied"]["count"], 1)

    def test_redirect(self):
        self.check_payload(self.run_download("/redirect"))

    def test_archive_redirect_blocked(self):
        r = self.run_download("/archive-redirect", expected=False)
        self.assertIn("Internet Archive", r["error"])
        self.assertFalse(list((self.path/"dl").glob("*.pkg")))

    def test_archive_catalog_entry_is_excluded(self):
        cat = self.catalog("/ok", urls=["https://dn710101.ca.archive.org/example.pkg"])
        p = subprocess.run([str(CLIENT), "list", str(cat)], capture_output=True, text=True, check=True)
        self.assertEqual(p.stdout, "")
        self.assertIn("excluded", p.stderr)

    def test_sha_mismatch_never_marked_complete(self):
        self.run_download("/ok", expected=False, sha256="0"*64)
        self.assertFalse(list((self.path/"dl").glob("*.pkg")))

    def test_manifest_size_mismatch_is_refused(self):
        r = self.run_download("/ok", expected=False, size_bytes=10)
        self.assertIn("size", r["error"])

    def test_partial_file_persists_across_processes(self):
        self.run_download("/cut", retries=0, expected=False)
        self.check_payload(self.run_download("/cut", retries=0))
        self.assertEqual(STATE["/cut"]["ranges"], [0, 65536])

    def test_pause_keeps_bytes_and_resume_works(self):
        cat = self.catalog("/slow")
        proc = subprocess.Popen([str(CLIENT), "download", str(cat), "test", str(self.path/"dl"), "0", "0"], text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        deadline = time.monotonic() + 4
        while time.monotonic() < deadline:
            parts = list((self.path/"dl").glob("*.part"))
            if parts and parts[0].stat().st_size > 16384:
                break
            time.sleep(0.01)
        proc.send_signal(signal.SIGINT)
        out, err = proc.communicate(timeout=5)
        self.assertEqual(proc.returncode, 3, err)
        self.assertTrue(json.loads(out)["paused"])
        self.check_payload(self.run_download("/slow"))
        self.assertGreater(STATE["/slow"]["ranges"][1], 0)

    def test_existing_receipt_is_checked(self):
        r = self.run_download("/ok")
        p = Path(r["path"])
        p.write_bytes(OTHER)
        r = self.run_download("/ok", expected=False)
        self.assertIn("receipt", r["error"])

    def test_queue_restart_pauses_interrupted_jobs(self):
        item = {"id":"job", "title":"Fixture", "urls":[self.url+"/ok"]}
        p = self.path/"queue.json"
        p.write_text(json.dumps({"schema":1, "jobs":[{"item":item,"state":"downloading"}]}))
        subprocess.run([str(CLIENT),"queue-check",str(p)],check=True,capture_output=True)
        saved = json.loads(Path(str(p)+".checked").read_text())
        self.assertEqual(saved["jobs"][0]["state"],"paused")

    def test_json_unicode_and_trailing_data(self):
        cat = self.catalog("/ok", title="Game \U0001f3ae")
        p = subprocess.run([str(CLIENT),"list",str(cat)],capture_output=True,text=True,check=True)
        self.assertIn("\U0001f3ae",p.stdout)
        cat.write_text(cat.read_text()+" trailing")
        p = subprocess.run([str(CLIENT),"list",str(cat)],capture_output=True,text=True)
        self.assertEqual(p.returncode,1)

    def test_sizes_above_four_gib_are_preserved(self):
        cat = self.catalog("/ok", size_bytes=5*1024**3)
        out = subprocess.check_output([str(CLIENT),"list",str(cat)],text=True)
        self.assertIn(str(5*1024**3),out)

    def test_sha256_against_python(self):
        for data in (b"", b"abc", b"x"*55, b"y"*56, b"z"*64, DATA):
            p = self.path/"hash"
            p.write_bytes(data)
            actual = subprocess.check_output([str(CLIENT),"hash",str(p)],text=True).strip()
            self.assertEqual(actual,hashlib.sha256(data).hexdigest())

    def test_refresh_failure_keeps_existing_catalog(self):
        cat = self.path/"cached.json"; cat.write_text('{"previous":"keep me"}')
        p = subprocess.run([str(CLIENT),"refresh",self.url+"/html",str(cat)],capture_output=True,text=True)
        self.assertEqual(p.returncode,1)
        self.assertEqual(cat.read_text(),'{"previous":"keep me"}')


if __name__ == "__main__":
    unittest.main()
