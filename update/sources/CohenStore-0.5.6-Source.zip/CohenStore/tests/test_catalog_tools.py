import json
from pathlib import Path
import struct
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]/"tools"))
from catalog_tools import allowed, normalize
from build_ps4 import read_sfo, write_sfo


class CatalogToolTests(unittest.TestCase):
    def test_excludes_archive_and_subdomains(self):
        for url in ("https://archive.org/a", "https://web.archive.org/a", "https://ARCHIVE.ORG./a"):
            with self.assertRaisesRegex(ValueError, "excluded"):
                allowed(url)

    def test_rejects_url_userinfo_and_encoded_authority(self):
        for url in ("https://user:pass@host.test/a", "https://%61rchive.org/a", "file:///pkg", "https://host.test/\r\n"):
            with self.assertRaises(ValueError):
                allowed(url)

    def test_share_pages_reported_not_marked_ready(self):
        catalog, report = normalize({"DATA":{"https://vikingfile.com/f/abc":{"name":"Test","size":"15GB"}}})
        self.assertEqual(catalog["items"],[])
        self.assertEqual(len(report["unresolved"]),1)

    def test_approximate_size_never_becomes_exact(self):
        c, _ = normalize({"DATA":{"https://files.test/download.pkg":{"name":"Test","size":"15GB"}}})
        self.assertEqual(c["items"][0]["size_bytes"],0)

    def test_exact_sizes_preserved(self):
        c, _ = normalize({"DATA":{"https://files.test/download.pkg":{"name":"Test","size":5000000000}}})
        self.assertEqual(c["items"][0]["size_bytes"],5000000000)

    def test_review_mode_labels_unresolved(self):
        c, r = normalize({"DATA":{"https://akirabox.com/public-id":{"name":"Test"}}},True)
        self.assertIn("still needed",c["items"][0]["note"])
        self.assertEqual(c["items"][0]["urls"],[])
        self.assertEqual(len(r["unresolved"]),1)

    def test_creator_reference_preserves_version_metadata(self):
        row = {"id":"menu", "title":"Menu", "format":"prx", "source_url":"https://creator.example/menu",
               "urls":[], "game_versions":["1.56"], "title_ids":["CUSA00419"]}
        c, _ = normalize({"schema":1,"items":[row]})
        self.assertEqual(c["items"],[row])

    def test_archive_creator_reference_is_excluded(self):
        c, r = normalize({"schema":1,"items":[{"id":"menu","title":"Menu","source_url":"https://archive.org/menu","urls":[]}]})
        self.assertEqual(c["items"],[])
        self.assertEqual(len(r["excluded"]),1)

    def test_catalog_with_archive_entry_filters_it(self):
        c, r = normalize({"schema":1,"items":[{"id":"x","title":"X","urls":["https://archive.org/a"]}]})
        self.assertEqual(c["items"],[])
        self.assertEqual(len(r["excluded"]),1)

    def test_duplicate_ids_are_not_imported_twice(self):
        entry={"id":"same","title":"X","urls":["https://files.test/a.pkg"]}
        c, r = normalize({"schema":1,"items":[entry,entry]})
        self.assertEqual(len(c["items"]),1)
        self.assertEqual(len(r["warnings"]),1)


class MetadataTests(unittest.TestCase):
    def test_sfo_roundtrip_preserves_format_and_values(self):
        rows=[("TITLE",0x204,b"Cohen Store Prototype\0",128),("ATTRIBUTE",0x404,struct.pack("<I",0),4)]
        actual=read_sfo(write_sfo(rows))
        self.assertEqual(actual,rows)

    def test_sfo_grows_value_with_alignment(self):
        rows=[("TITLE",0x204,b"Longer title\0",4)]
        actual=read_sfo(write_sfo(rows))
        self.assertEqual(actual[0][2],rows[0][2])
        self.assertGreaterEqual(actual[0][3],len(rows[0][2]))
        self.assertEqual(actual[0][3]%4,0)

    def test_sfo_invalid_magic(self):
        with self.assertRaises(ValueError):
            read_sfo(struct.pack("<5I",0,0x101,20,20,0))


if __name__=="__main__":
    unittest.main()
