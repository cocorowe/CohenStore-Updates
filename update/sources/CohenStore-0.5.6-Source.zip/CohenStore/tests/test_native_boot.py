"""Run the actual native frontend with a strict display and fake controller."""
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
ITEM={'id':'fixture','title':'Fixture','category':'games','urls':['https://example.test/file.pkg']}

class NativeBootTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory()
        p=cls.path=Path(cls.temp.name);(p/'orbis').mkdir()
        (p/'graphics.h').write_text(r'''
#include <cstdint>
#include <stdexcept>
struct Color {uint8_t r,g,b;};
class Scene2D { public:
Scene2D(int,int,int){} ~Scene2D(); bool Init(int,int){return true;}
int buffer=-1; void SetActiveFrameBuffer(int i){buffer=i;}
void CopyFrame(const uint32_t*){if(buffer!=0) throw std::runtime_error("Frame buffer not initialized");}
void DrawRectangle(int,int,int,int,Color){} void FrameBufferClear(){}
void SubmitFlip(int){} void FrameWait(int){} void FrameBufferSwap(){}
};''')
        (p/'orbis/UserService.h').write_text('inline int sceUserServiceInitialize(void*){return 0;} inline int sceUserServiceGetInitialUser(int* u){*u=0;return 0;}')
        (p/'orbis/Pad.h').write_text(r'''
#include <cstdint>
#include <cstdlib>
#include <chrono>
#include <thread>
#include <vector>
struct OrbisPadData {uint32_t buttons;};
inline int scePadInit(){return 0;} inline int scePadOpen(int,int,int,void*){return 1;}
inline int scePadClose(int){return 0;}
inline int scePadReadState(int,OrbisPadData* d){
 static std::vector<uint32_t> keys=[] {std::vector<uint32_t> k;const char* p=std::getenv("COHEN_TEST_KEYS");while(p && *p){char* e=nullptr;k.push_back(std::strtoul(p,&e,16));p=*e?e+1:e;}return k;}();
 static size_t i=0;std::this_thread::sleep_for(std::chrono::milliseconds(20));d->buttons=i<keys.size()?keys[i++]:8;return 0;
}
''')
        source=(ROOT/'ps4/main.cpp').read_text()
        source=source.replace('"/app0/assets/fonts/ui.cfn"',json.dumps(str(ROOT/'assets/fonts/ui.cfn')))
        source=source.replace('"/app0/assets/catalog.json"',json.dumps(str(ROOT/'catalog/catalog.json')))
        source=source.replace('"/data/CohenStore"','std::getenv("COHEN_TEST_DATA")')
        source=source.replace('"/data/CohenStore-diagnostics.txt"','std::getenv("COHEN_TEST_DIAGNOSTICS")')
        (p/'main.cpp').write_text(source)
        (p/'transport.cpp').write_text(r'''
#include "cohen/store.hpp"
#include <cstdlib>
#include <cstdio>
namespace cohen {
std::unique_ptr<Transport> make_transport(){
 FILE* f=std::fopen(std::getenv("COHEN_TEST_ATTEMPTS"),"a");if(f){std::fputs("attempt\n",f);std::fclose(f);}
 throw std::runtime_error("Fixture network unavailable");
}
}
''')
        command=['g++','-std=c++17','-O1','-D_GLIBCXX_ASSERTIONS','-I'+str(p),'-I'+str(ROOT/'include'),str(p/'main.cpp'),str(p/'transport.cpp')]
        command += [str(ROOT/n) for n in ['src/ui.cpp','src/catalog.cpp','src/download.cpp','src/sha256.cpp','src/update.cpp','vendor/monocypher/monocypher.c','vendor/monocypher/monocypher-ed25519.c']]
        command += ['-pthread','-o',str(p/'boot-test')]
        subprocess.run(command,check=True,capture_output=True)

    @classmethod
    def tearDownClass(cls): cls.temp.cleanup()

    def run_fixture(self,keys,*,first=False,corrupt=False,jobs=None):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup)
        p=Path(temp.name);data=p/'data';data.mkdir()
        (data/'catalog.json').write_text('broken' if corrupt else json.dumps({'schema':1,'items':[ITEM]}))
        if jobs is None: jobs=[{'item':dict(ITEM,id=str(i)),'state':'complete'} for i in range(30)]
        (data/'queue.json').write_text('broken' if corrupt else json.dumps({'schema':1,'jobs':jobs}))
        (data/'settings.json').write_text('{"check_startup":true,"auto_updates":true}' if first else '{"check_startup":false}')
        (data/'mint-layout-v05').write_text('1')
        if not first:(data/'repair-052').write_text('1')
        (data/'catalog_url.txt').write_text('https://example.test/catalog.json')
        env=dict(os.environ,COHEN_TEST_DATA=str(data),COHEN_TEST_DIAGNOSTICS=str(p/'diagnostics.txt'),COHEN_TEST_ATTEMPTS=str(p/'attempts.txt'),COHEN_TEST_KEYS=','.join(format(k,'x') for k in keys))
        r=subprocess.run([str(self.path/'boot-test')],env=env,capture_output=True,text=True,timeout=15)
        self.assertEqual(r.returncode,0,r.stderr)
        log=(data/'startup.log').read_text()
        self.assertIn('First frame presented',log)
        self.assertIn('Worker started after first frame',log)
        self.assertTrue((p/'diagnostics.txt').is_file())
        return p,data,log

    def test_queue_to_catalog_keeps_indexes_in_correct_collection(self):
        self.run_fixture([0x8000,0,0x8000,0,0x800,0,8])

    def test_first_repair_launch_does_not_initialize_network(self):
        p,data,_=self.run_fixture([0]*15+[8],first=True)
        self.assertFalse((p/'attempts.txt').exists())
        settings=json.loads((data/'settings.json').read_text())
        self.assertFalse(settings['check_startup']);self.assertFalse(settings['auto_updates'])
        self.assertTrue(json.loads((data/'settings.before-052.json').read_text())['check_startup'])

    def test_bad_cache_falls_back_and_bad_queue_is_preserved(self):
        _,data,log=self.run_fixture([0x4000,0]+[0]*10+[8],corrupt=True)
        self.assertEqual((data/'queue.json').read_text(),'broken')
        self.assertIn('Invalid JSON',log)

    def test_network_failure_is_reported_after_first_frame_without_retry_loop(self):
        p,_,log=self.run_fixture([0,4,0]+[0]*18+[8])
        self.assertEqual((p/'attempts.txt').read_text().count('attempt'),1)
        self.assertLess(log.index('First frame presented'),log.index('Network initialization requested'))
        self.assertIn('Fixture network unavailable',log)

    def test_all_sections_and_settings_are_navigable(self):
        self.run_fixture([key for _ in range(12) for key in (0x800,0)]+[8])

    def test_catalog_retry_replaces_stale_queued_link(self):
        old=dict(ITEM,urls=['https://example.test/dead.pkg'],size_bytes=123)
        _,data,_=self.run_fixture([0x4000,0]+[0]*10+[8],jobs=[{'item':old,'state':'failed'}])
        job=json.loads((data/'queue.json').read_text())['jobs'][0]
        self.assertEqual(job['item']['urls'],ITEM['urls'])
        self.assertEqual(job['item']['size_bytes'],0)

    def test_queue_retry_replaces_stale_queued_link(self):
        old=dict(ITEM,urls=['https://example.test/dead.pkg'])
        _,data,_=self.run_fixture([0x8000,0,0x4000,0]+[0]*10+[8],jobs=[{'item':old,'state':'paused'}])
        job=json.loads((data/'queue.json').read_text())['jobs'][0]
        self.assertEqual(job['item']['urls'],ITEM['urls'])
