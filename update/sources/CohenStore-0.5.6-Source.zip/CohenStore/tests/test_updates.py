import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

ROOT=Path(__file__).resolve().parents[1]

class UpdateTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        cls.path=Path(cls.tmp.name)
        cls.key=Ed25519PrivateKey.generate()
        public=cls.key.public_key().public_bytes(serialization.Encoding.Raw,serialization.PublicFormat.Raw).hex()
        (cls.path/'cohen').mkdir()
        (cls.path/'cohen/update_key.hpp').write_text('#define COHEN_UPDATE_PUBLIC_KEY "'+public+'"\n')
        (cls.path/'main.cpp').write_text('''#include "cohen/update.hpp"
#include <iostream>
int main(int argc,char** argv) {try {
 if(argc!=5)return 2;
 auto update=cohen::verify_update(cohen::read_file(argv[1]),std::stoull(argv[2]));
 if(std::string(argv[3])!="-") {
 if(std::string(argv[4])=="verify")cohen::verify_update_package(update,argv[3]);
 else cohen::stage_update_package(update,argv[3],argv[4],[]{return std::getenv("CANCEL")!=nullptr;});
 }
 std::cout<<update.version; return 0;
}catch(const std::exception& e){std::cerr<<e.what();return 1;}}
''')
        subprocess.run(['g++','-std=c++17','-O2','-I'+str(cls.path),'-I'+str(ROOT/'include'),
                        str(cls.path/'main.cpp'),str(ROOT/'src/update.cpp'),str(ROOT/'src/catalog.cpp'),
                        str(ROOT/'src/sha256.cpp'),str(ROOT/'vendor/monocypher/monocypher.c'),
                        str(ROOT/'vendor/monocypher/monocypher-ed25519.c'),'-o',str(cls.path/'check')],check=True,capture_output=True)
    @classmethod
    def tearDownClass(cls): cls.tmp.cleanup()

    def setUp(self):
        self.pkg=bytearray(1024)
        self.pkg[:4]=b'\x7fCNT'
        self.pkg[0x40:0x64]=b'IV0000-CHST00001_00-COHENSTORE000000'
        self.data=dict(schema=1,channel='testing',revision=2,version='0.5.6',version_code=56,
                       title_id='CHST00001',content_id='IV0000-CHST00001_00-COHENSTORE000000',
                       size_bytes=len(self.pkg),sha256=hashlib.sha256(self.pkg).hexdigest(),
                       url='https://raw.githubusercontent.com/cocorowe/CohenStore-Updates/main/update/packages/test.pkg')

    def check(self,ok=True,minimum=0,package=False,alter_signature=False,alter_payload=False,stage=False,cancel=False):
        payload=json.dumps(self.data,sort_keys=True,separators=(',',':'))
        sig=self.key.sign(payload.encode()).hex()
        if alter_signature: sig=('00' if sig[:2]!='00' else '01')+sig[2:]
        if alter_payload: payload=payload.replace('0.5.6','0.9.9')
        (self.path/'manifest').write_text(json.dumps(dict(signed_payload=payload,signature=sig)))
        (self.path/'package').write_bytes(self.pkg)
        result=subprocess.run([str(self.path/'check'),str(self.path/'manifest'),str(minimum),str(self.path/'package') if package else '-',str(self.path/'stage') if stage else 'verify'],capture_output=True,text=True,env=dict(__import__('os').environ,**({'CANCEL':'1'} if cancel else {})))
        self.assertEqual(result.returncode,0 if ok else 1,result.stderr)

    def test_verified_package_is_staged(self):
        self.check(package=True,stage=True)
        self.assertEqual((self.path/'stage/CohenStore-56.pkg').read_bytes(),self.pkg)
        self.assertFalse((self.path/'package').exists())
    def test_cancelled_package_stays_unstaged(self):
        target=self.path/'stage/CohenStore-56.pkg'
        target.unlink(missing_ok=True)
        self.check(False,package=True,stage=True,cancel=True)
        self.assertFalse(target.exists())
        self.assertTrue((self.path/'package').exists())
    def test_signed_manifest_and_package(self): self.check(package=True)
    def test_modified_signature(self): self.check(False,alter_signature=True)
    def test_modified_manifest(self): self.check(False,alter_payload=True)
    def test_rollback_revision(self): self.check(False,minimum=3)
    def test_installed_version_rollback(self): self.data['version_code']=54; self.check(False)
    def test_wrong_title(self): self.data['title_id']='CHST00002'; self.check(False)
    def test_http_url(self): self.data['url']=self.data['url'].replace('https:','http:'); self.check(False)
    def test_other_repository(self): self.data['url']=self.data['url'].replace('cocorowe','someone'); self.check(False)
    def test_changed_download(self): self.pkg[-1]=1; self.check(False,package=True)
    def test_wrong_size(self): self.pkg.extend(b'1'); self.check(False,package=True)
    def test_wrong_pkg_identity_even_with_matching_hash(self):
        self.pkg[0x40]=0; self.data['sha256']=hashlib.sha256(self.pkg).hexdigest(); self.check(False,package=True)
    def test_malformed_digest(self):
        self.data['sha256']='invalid'; self.check(False)
