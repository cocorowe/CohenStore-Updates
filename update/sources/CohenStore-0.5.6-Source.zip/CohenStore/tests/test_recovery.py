"""Verify the offline recovery app reads bounded logs and preserves store files."""
import json
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]

class RecoveryTests(unittest.TestCase):
    def test_report_export_keeps_original_store_files(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp);data=p/'store';data.mkdir();(p/'orbis').mkdir()
            (p/'graphics.h').write_text('''#include <cstdint>
#include <stdexcept>
struct Color {uint8_t r,g,b;};
struct Scene2D {int index=-1;Scene2D(int,int,int){}~Scene2D();
bool Init(int,int){return true;}void SetActiveFrameBuffer(int i){index=i;}
void DrawRectangle(int,int,int,int,Color){if(index!=0)throw std::runtime_error("Bad frame buffer");}
void FrameBufferFill(Color c){DrawRectangle(0,0,0,0,c);}void SubmitFlip(int){}void FrameWait(int){}void FrameBufferSwap(){}
};''')
            (p/'orbis/UserService.h').write_text('inline int sceUserServiceInitialize(void*){return 0;}inline int sceUserServiceGetInitialUser(int* i){*i=0;return 0;}')
            (p/'orbis/Pad.h').write_text('''#include <cstdint>
struct OrbisPadData{uint32_t buttons;};inline int scePadInit(){return 0;}inline int scePadOpen(int,int,int,void*){return 1;}inline int scePadClose(int){return 0;}
inline int scePadReadState(int,OrbisPadData* p){static int n=0;p->buttons=n++?8:0;return 0;}
''')
            originals={'startup.log':b'old line\n'*2000+b'Last crash stage\n','queue.json':b'broken queue','catalog.json':b'original catalog','settings.json':b'original settings'}
            for name,content in originals.items():(data/name).write_bytes(content)
            diagnostic=p/'diagnostic.txt';diagnostic.write_text('outside log\n')
            report=p/'report.txt'
            source=(ROOT/'ps4/recovery.cpp').read_text().replace('"/data/CohenStore/"',json.dumps(str(data)+'/'))
            source=source.replace('"/data/CohenStore/startup.log"',json.dumps(str(data/'startup.log')))
            source=source.replace('"/data/CohenStore-diagnostics.txt"',json.dumps(str(diagnostic))).replace('"/data/CohenStore-recovery.txt"',json.dumps(str(report)))
            (p/'recovery.cpp').write_text(source)
            subprocess.run(['g++','-std=c++17','-O1','-I'+str(p),str(p/'recovery.cpp'),'-o',str(p/'recovery')],check=True,capture_output=True)
            r=subprocess.run([str(p/'recovery')],timeout=10,capture_output=True)
            self.assertEqual(r.returncode,0,r.stderr)
            for name,content in originals.items():self.assertEqual((data/name).read_bytes(),content)
            self.assertIn('Last crash stage',report.read_text());self.assertIn('outside log',report.read_text())
            self.assertLess(report.stat().st_size,20000)
