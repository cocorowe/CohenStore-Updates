"""Exercise the actual PS4 adapter with simulated system APIs, including ABI args."""
import os
from pathlib import Path
import subprocess
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


class NativeTransportTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        p = cls.path = Path(cls.temp.name)
        (p/'orbis').mkdir()
        for name in ('Http.h', 'Net.h', 'NetCtl.h', 'Ssl.h', 'Sysmodule.h', 'libkernel.h'):
            (p/'orbis'/name).write_text('#include "api.hpp"\n')
        (p/'orbis/api.hpp').write_text(r'''
#pragma once
#include <cstdint>
#include <cstddef>
enum M {ORBIS_SYSMODULE_INTERNAL_NET=1, ORBIS_SYSMODULE_INTERNAL_NETCTL=2,
        ORBIS_SYSMODULE_INTERNAL_SSL=3, ORBIS_SYSMODULE_INTERNAL_HTTP=4};
extern "C" {
int sceSysmoduleLoadModuleInternal(M);
int sceNetInit(); int sceNetTerm(); int sceNetCtlInit(); int sceNetCtlTerm();
int sceNetPoolCreate(const char*,int,int); int sceNetPoolDestroy(int);
int sceSslInit(int); int sceSslTerm();
int sceHttpInit(int,int,int); int sceHttpTerm(int);
int sceHttpCreateTemplate(int,const char*,int,int); int sceHttpDeleteTemplate(int);
int sceHttpCreateConnectionWithURL(int,const char*,bool); int sceHttpDeleteConnection(int);
int sceHttpCreateRequestWithURL(int,int,const char*,uint64_t); int sceHttpDeleteRequest(int);
int sceHttpSetResponseHeaderMaxSize(); int sceHttpSetAutoRedirect(); int sceHttpSetRecvTimeOut();
int sceHttpSetConnectTimeOut(int,uint32_t); int sceHttpSetResolveTimeOut(int,uint32_t);
int sceHttpAddRequestHeader(int,const char*,const char*,int);
int sceHttpSendRequest(int,const void*,size_t); int sceHttpGetStatusCode(int,int*);
int sceHttpGetAllResponseHeaders(int,char**,size_t*); int sceHttpReadData(int,void*,uint32_t);
int sceHttpAbortRequest(int);
}
''')
        (p/'test.cpp').write_text(r'''
#include "cohen/store.hpp"
#include <cassert>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>
#include <pthread.h>
// Implementations use the real parameter lists. The adapter header intentionally
// mirrors the incomplete SDK declarations to ensure our aliases keep their args.
static size_t headerLimit=0;
static int failure=0, termSsl=-1,termHttp=-1,termPool=-1,ctlTerms=0,netTerms=0;
static int deletes=0,redirectId=0,redirectFlag=-1,timeoutId=0;static uint32_t timeout=0;
static std::vector<int> modules;
extern "C" {
int sceSysmoduleLoadModuleInternal(int id){modules.push_back(id);return failure==id?-42:0;}
int sceNetInit(){return 0;} int sceNetTerm(){++netTerms;return 0;}
int sceNetCtlInit(){return 0;} int sceNetCtlTerm(){++ctlTerms;return 0;}
int sceNetPoolCreate(const char*,int,int){return 6;} int sceNetPoolDestroy(int id){termPool=id;return 0;}
int sceSslInit(int){return 7;} int sceSslTerm(int id){termSsl=id;return 0;}
int sceHttpInit(int pool,int ssl,int){assert(pool==6 && ssl==7);return failure==5?-55:8;}
int sceHttpTerm(int id){termHttp=id;return 0;}
int sceHttpCreateTemplate(int id,const char*,int,int){assert(id==8);return 9;}
int sceHttpDeleteTemplate(int id){assert(id==9);++deletes;return 0;}
int sceHttpCreateConnectionWithURL(int,const char*,bool){return 10;}
int sceHttpDeleteConnection(int id){assert(id==10);++deletes;return 0;}
int sceHttpCreateRequestWithURL(int,int,const char*,uint64_t){return 11;}
int sceHttpDeleteRequest(int id){assert(id==11);++deletes;return 0;}
int sceHttpSetResponseHeaderMaxSize(int id,size_t n){assert(id==9 && n==65536);headerLimit=n;return 0;}
int sceHttpSetAutoRedirect(int id,int flag){redirectId=id;redirectFlag=flag;return 0;}
int sceHttpSetRecvTimeOut(int id,uint32_t value){timeoutId=id;timeout=value;return 0;}
int sceHttpSetConnectTimeOut(int,uint32_t){return 0;} int sceHttpSetResolveTimeOut(int,uint32_t){return 0;}
int sceHttpAddRequestHeader(int,const char*,const char*,int){return 0;}
int sceHttpSendRequest(int,const void*,size_t){return headerLimit>=65536?0:static_cast<int>(0x80431073U);}
int sceHttpGetStatusCode(int,int* s){*s=200;return 0;}
int sceHttpGetAllResponseHeaders(int,char** p,size_t* n){static char h[]="Content-Length: 4\r\n";*p=h;*n=failure==6?300000:sizeof(h)-1;return 0;}
int sceHttpReadData(int,void* p,uint32_t){static bool done=false;if(done)return 0;std::memcpy(p,"TEST",4);done=true;return 4;}
int sceHttpAbortRequest(int){return 0;}
}
int exercise(int argc,char** argv) {
    assert(argc==2);failure=std::atoi(argv[1]);bool caught=false;
    try {
        auto t=cohen::make_transport();
        assert(failure!=1 && failure!=5);
        std::string body;
        auto err=t->get("https://example.test/a",{},[&](const cohen::Response& h){
            assert(h.status==200);if(failure==7)throw std::runtime_error("callback error");return true;
        },[&](const char* p,size_t n){body.append(p,n);return true;},[]{return false;});
        if(failure==6) assert(err.find("headers exceed limit")!=std::string::npos);
        else if(failure==7) assert(err=="example.test: callback error");
        else assert(err.empty() && body=="TEST");
        assert(deletes==3 && redirectId==9 && redirectFlag==0 && timeoutId==9 && timeout==30000000);
    } catch(const std::runtime_error&) {caught=true;assert(failure==1 || failure==5);}
    assert(modules.front()==1);
    if(failure==1) {assert(caught && termSsl==-1 && termPool==-1 && netTerms==0);}
    else {assert(modules==std::vector<int>({1,2,3,4}));assert(termSsl==7 && termPool==6 && ctlTerms==1 && netTerms==1);}
    if(failure==5)assert(caught && termHttp==-1);else if(failure!=1)assert(termHttp==8);
    return 0;
}
void* small_stack(void*) {char a[]="test",b[]="0";char* args[]={a,b};exercise(2,args);return nullptr;}
int main(int argc,char** argv) {
 if(argc==2 && std::atoi(argv[1])==8) {
  pthread_attr_t attr;assert(pthread_attr_init(&attr)==0);assert(pthread_attr_setstacksize(&attr,64*1024)==0);
  pthread_t thread;assert(pthread_create(&thread,&attr,small_stack,nullptr)==0);pthread_attr_destroy(&attr);assert(pthread_join(thread,nullptr)==0);return 0;
 }
 return exercise(argc,argv);
}
''')
        cmd=['g++','-std=c++17','-O1','-fsanitize=address,undefined','-fno-omit-frame-pointer',
             '-I'+str(p),'-I'+str(ROOT/'include'),str(ROOT/'ps4/http_native.cpp'),
             str(ROOT/'src/catalog.cpp'),str(p/'test.cpp'),'-o',str(p/'adapter-test')]
        subprocess.run(cmd,check=True,capture_output=True)

    @classmethod
    def tearDownClass(cls):
        cls.temp.cleanup()

    def run_mode(self, mode):
        env=dict(os.environ,ASAN_OPTIONS='detect_leaks=0')
        r=subprocess.run([str(self.path/'adapter-test'),str(mode)],env=env,capture_output=True,text=True,timeout=10)
        self.assertEqual(r.returncode,0,r.stderr)

    def test_real_parameter_lists_and_cleanup(self): self.run_mode(0)
    def test_missing_module_fails_without_context_cleanup(self): self.run_mode(1)
    def test_partial_initialization_cleans_only_owned_contexts(self): self.run_mode(5)
    def test_oversized_headers_do_not_read_past_buffer(self): self.run_mode(6)
    def test_callback_exception_closes_request_resources(self): self.run_mode(7)

    def test_request_does_not_require_a_64_kib_stack_buffer(self): self.run_mode(8)
