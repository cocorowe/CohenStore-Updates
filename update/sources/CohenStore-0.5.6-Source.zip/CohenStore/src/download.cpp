#include "cohen/store.hpp"
#include <algorithm>
#include <array>
#include <cerrno>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <sys/stat.h>
#include <sys/statvfs.h>
#include <thread>
#include <unistd.h>

namespace cohen {
namespace {
uint64_t file_size(const std::string& p) {
    FILE* f=std::fopen(p.c_str(),"rb");if(!f)return 0;
    uint64_t result=0;
    if(fseeko(f,0,SEEK_END)==0) {off_t n=ftello(f);if(n>0)result=static_cast<uint64_t>(n);}
    std::fclose(f);return result;
}
uint64_t decimal(const std::string& s) {
    Json j; j.kind=Json::Number; j.text=s;
    return j.u64();
}
bool strong_etag(const std::string& s) {
    return s.size()>=2 && s.front()=='"' && s.back()=='"' && s.find_first_of("\r\n")==std::string::npos;
}
bool file_magic(const std::string& p,const std::string& format) {
    FILE* f=std::fopen(p.c_str(),"rb"); if(!f) return false;
    unsigned char b[4]={}; size_t n=std::fread(b,1,4,f); std::fclose(f);
    if(format=="prx")
        return n==4 && ((b[0]==0x4f && b[1]==0x15 && b[2]==0x3d && b[3]==0x1d)
            || (b[0]==0x7f && b[1]=='E' && b[2]=='L' && b[3]=='F'));
    return n==4 && b[0]==0x7f && b[1]=='C' && b[2]=='N' && b[3]=='T';
}
void disk_space(const std::string& directory,uint64_t needed,uint64_t reserve) {
    struct statvfs fs;
    if(statvfs(directory.c_str(),&fs)==0) {
        uint64_t block=fs.f_frsize ? fs.f_frsize : fs.f_bsize;
        uint64_t free=uint64_t(fs.f_bavail)*block;
        if(free<needed || free-needed<reserve) throw std::runtime_error("Not enough free storage for this download");
    }
}
void interruptible_wait(unsigned ms,const Cancel& cancel) {
    for(unsigned t=0;t<ms && !cancel();t+=50)
        std::this_thread::sleep_for(std::chrono::milliseconds(std::min(50U,ms-t)));
}
}
Result Engine::download(const Item& item,const std::string& dir,std::function<void(const Progress&)> notify,Cancel cancel,const Options& opt) {
    Result result; Progress progress;
    auto report=[&](const std::string& message){progress.message=message; if(notify) notify(progress);};
    if(!item.downloadable()) { result.error="Creator reference only. A verified direct file link is still needed."; return result; }
    if(item.format!="pkg" && item.format!="prx") { result.error="Unsupported download format"; return result; }
    const std::string base=dir+"/"+item_key(item), part=base+"."+item.format+".part", meta_path=part+".json", final=base+"."+item.format;
    try {
        if(mkdir(dir.c_str(),0700)!=0 && errno!=EEXIST) throw std::runtime_error("Cannot create download directory");
        if(file_size(final)>0) {
            try {
                Json receipt=Json::parse(read_file(final+".json"));
                std::string hash=sha256_file(final,cancel);
                if(receipt.at("id").str()==item.id && receipt.at("size_bytes").u64()==file_size(final)
                    && receipt.at("sha256").str()==hash && (item.sha256.empty() || item.sha256==hash)
                    && (!item.size || item.size==file_size(final)) && file_magic(final,item.format)) {
                    result.ok=true; result.path=final; result.bytes=file_size(final); report("Already downloaded and checked"); return result;
                }
            } catch(const std::exception&) {}
            throw std::runtime_error("An existing package failed its receipt check; keep it for inspection before replacing it");
        }
        for(const std::string& origin:item.urls) {
            allow_url(origin);
            if(provider_page(origin)) {
                result.error="This entry points to a download webpage. A direct package URL is required.";
                continue;
            }
            for(unsigned attempt=0;attempt<=opt.retries;++attempt) {
                if(cancel()) { result.paused=true; result.error="Paused; partial download kept"; return result; }
                progress.attempt=attempt+1;
                uint64_t offset=file_size(part), old_total=0; std::string etag;
                try {
                    Json m=Json::parse(read_file(meta_path,65536));
                    if(m.at("url").str()==origin && m.at("id").str()==item.id) {
                        etag=m.at("etag").str(); old_total=m.at("total").u64();
                    }
                } catch(const std::exception&) {}
                // Never append to an unvalidated representation or to a different mirror.
                if(offset && (!strong_etag(etag) || !old_total || offset>=old_total)) {
                    offset=0; etag.clear();
                }
                progress.done=offset; progress.total=old_total;
                report(offset ? "Resuming partial download" : "Connecting");
                std::string url=origin, error; bool fatal=false, accepted=false;
                uint64_t total=0, written=offset;
                FILE* out=nullptr; unsigned retry_after=0;
                for(unsigned redirects=0;redirects<=5;++redirects) {
                    allow_url(url); Response response; std::string location;
                    std::map<std::string,std::string> request={{"Accept-Encoding","identity"}};
                    if(offset) { request["Range"]="bytes="+std::to_string(offset)+"-"; request["If-Range"]=etag; }
                    auto headers=[&](const Response& h)->bool {
                        response=h;
                        if(h.status==301 || h.status==302 || h.status==303 || h.status==307 || h.status==308) {
                            location=h.get("location"); return false;
                        }
                        if(h.status!=200 && h.status!=206) {
                            error="HTTP "+std::to_string(h.status);
                            if(h.status==401 || h.status==403) error+=": host requires authorization or denied the download";
                            if(h.status==404 || h.status==410) error+=": file is unavailable";
                            fatal=!(h.status==408 || h.status==429 || h.status>=500);
                            retry_after=static_cast<unsigned>(std::min<uint64_t>(30,decimal(h.get("retry-after"))));
                            return false;
                        }
                        if(lower(h.get("content-type")).find("text/html")!=std::string::npos) {
                            fatal=true; error="Host returned a webpage instead of a package"; return false;
                        }
                        if(!h.get("content-encoding").empty() && lower(h.get("content-encoding"))!="identity") {
                            fatal=true; error="Encoded package transfer refused"; return false;
                        }
                        uint64_t start=0,finish=0;
                        if(h.status==206) {
                            unsigned long long a=0,b=0,c=0; char extra=0;
                            std::string cr=h.get("content-range");
                            if(std::sscanf(cr.c_str(),"bytes %llu-%llu/%llu%c",&a,&b,&c,&extra)!=3 || a!=offset || b<a || b>=c) {
                                fatal=true; error="Host returned an invalid resume range"; return false;
                            }
                            start=a; finish=b; total=c;
                            uint64_t content_len=decimal(h.get("content-length"));
                            if(content_len && content_len!=finish-start+1) {
                                fatal=true; error="Resume length does not match Content-Range"; return false;
                            }
                            if(offset && ((!h.get("etag").empty() && h.get("etag")!=etag) || (old_total && total!=old_total))) {
                                fatal=true; error="The remote file changed; partial download was kept"; return false;
                            }
                        } else {
                            // A 200 response to Range means restart, never append duplicate bytes.
                            start=0; offset=0; written=0; total=decimal(h.get("content-length"));
                        }
                        if(!total) total=item.size;
                        if(!total || total>512ULL*1024*1024*1024 || total<=start || (item.size && total!=item.size)) {
                            fatal=true; error="Missing or conflicting package size"; return false;
                        }
                        disk_space(dir,total-start,opt.reserve_bytes);
                        out=std::fopen(part.c_str(),start?"ab":"wb");
                        if(!out) { fatal=true; error="Cannot open partial download for writing"; return false; }
                        Json m=Json::obj(); m.object["id"]=Json(item.id); m.object["url"]=Json(origin);
                        m.object["etag"]=Json(h.get("etag")); m.object["total"]=Json::num(total);
                        write_atomic(meta_path,m.dump());
                        accepted=true; written=start; progress.done=start; progress.total=total; report("Downloading"); return true;
                    };
                    auto body=[&](const char* data,size_t n)->bool {
                        if(cancel()) return false;
                        if(!out || n>total-written) { fatal=true; error="Transfer exceeds the expected file size"; return false; }
                        size_t count=std::fwrite(data,1,n,out);
                        written+=count; progress.done=written;
                        if(count!=n) { fatal=true; error="Storage write failed; partial download kept"; return false; }
                        report("Downloading"); return true;
                    };
                    std::string transport_error;
                    try { transport_error=transport_.get(url,request,headers,body,cancel); }
                    catch(const std::exception& e) { transport_error=e.what(); }
                    if(out) {
                        if(std::fflush(out)!=0 || fsync(fileno(out))!=0) { fatal=true; error="Cannot flush partial download to storage"; }
                        if(std::fclose(out)!=0) { fatal=true; error="Cannot close partial download"; }
                        out=nullptr;
                    }
                    if(cancel()) { result.paused=true; result.bytes=written; result.error="Paused; partial download kept"; return result; }
                    if(!location.empty()) {
                        if(redirects==5) { fatal=true; error="Too many redirects"; break; }
                        url=resolve_url(url,location); continue;
                    }
                    if(!transport_error.empty() && error.empty()) error=transport_error;
                    break;
                }
                result.bytes=written;
                if(accepted && !fatal && error.empty() && written==total) {
                    if(!file_magic(part,item.format)) { result.error="Downloaded file does not match the selected "+item.format+" format"; return result; }
                    report("Checking downloaded file");
                    std::string hash=sha256_file(part,cancel);
                    if(!item.sha256.empty() && hash!=item.sha256) {
                        result.error="SHA-256 mismatch; package was not marked complete"; return result;
                    }
                    Json receipt=Json::obj(); receipt.object["id"]=Json(item.id); receipt.object["title"]=Json(item.title);
                    receipt.object["size_bytes"]=Json::num(written); receipt.object["sha256"]=Json(hash);
                    write_atomic(final+".json",receipt.dump());
                    if(std::rename(part.c_str(),final.c_str())!=0) throw std::runtime_error("Cannot finalize downloaded package");
                    std::remove(meta_path.c_str());
                    result.ok=true; result.path=final; result.error.clear(); report("Download complete"); return result;
                }
                if(error.empty()) error="Connection ended before the file finished";
                result.error=error; report(error);
                if(fatal) break;
                if(attempt<opt.retries) {
                    uint64_t delay=uint64_t(opt.retry_delay_ms)*(1ULL<<std::min(attempt,5U));
                    delay=std::max(delay,uint64_t(retry_after)*1000);
                    report("Connection interrupted; retrying");
                    interruptible_wait(static_cast<unsigned>(std::min<uint64_t>(30000,delay)),cancel);
                }
            }
        }
    } catch(const std::exception& e) {
        result.error=e.what();
        if(cancel()) result.paused=true;
    }
    if(result.error.empty()) result.error="No usable download URL";
    return result;
}
std::string Engine::fetch_text(const std::string& origin,Cancel cancel) {
    std::string url=origin;
    for(unsigned redirects=0;redirects<=5;++redirects) {
        allow_url(url); Response response; std::string data;
        std::string err=transport_.get(url,{{"Accept-Encoding","identity"}},[&](const Response& h) {
            response=h; return h.status==200;
        },[&](const char* p,size_t n) {
            if(data.size()+n>32*1024*1024) throw std::runtime_error("Catalog exceeds 32 MiB");
            data.append(p,n); return !cancel();
        },cancel);
        if(cancel()) throw std::runtime_error("Catalog refresh cancelled");
        if(response.status==301 || response.status==302 || response.status==303 || response.status==307 || response.status==308) {
            url=resolve_url(url,response.get("location")); continue;
        }
        if(!err.empty()) throw std::runtime_error(err);
        if(response.status!=200) throw std::runtime_error("Catalog HTTP "+std::to_string(response.status));
        return data;
    }
    throw std::runtime_error("Too many catalog redirects");
}
}
