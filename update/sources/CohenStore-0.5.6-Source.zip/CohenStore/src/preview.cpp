#include "cohen/ui.hpp"
#include <iostream>
int main(int argc,char** argv) {
    if(argc<4) return 2;
    try {
        cohen::ui::Canvas c; c.load_fonts(argv[1]);
        std::string assetroot=argv[1]; assetroot=assetroot.substr(0,assetroot.rfind("/fonts/"));
        for(const std::string key:{"SKID02048","RHZR00001"}) { try { c.load_cover(key,assetroot+"/art/"+key+".cimg"); } catch(...) {} }
        cohen::ui::View v; v.catalog=cohen::catalog_read(cohen::read_file(argv[2]));
        v.category=argc>4?argv[4]:"all"; v.network_ready=false;
        v.status="Developer-published game downloads included. Console testing is still required.";
        cohen::ui::render(c,v); c.save_ppm(argv[3]);
        return 0;
    } catch(const std::exception& e) { std::cerr<<e.what()<<"\n"; return 1; }
}
