#include "cohen/store.hpp"
#include <array>
#include <cstdio>
#include <cstring>
#include <stdexcept>

namespace cohen {
namespace {
uint32_t rotate(uint32_t v, unsigned n) { return (v >> n) | (v << (32-n)); }
class Hash {
    uint32_t state_[8] = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
    unsigned char buffer_[64] = {};
    size_t buffered_ = 0;
    uint64_t bytes_ = 0;
    void block(const unsigned char* in) {
        static const uint32_t k[64] = {
            0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
            0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
            0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
            0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
            0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
            0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
            0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
            0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2};
        uint32_t w[64];
        for (unsigned i=0; i<16; ++i) w[i] = uint32_t(in[i*4])<<24 | uint32_t(in[i*4+1])<<16 | uint32_t(in[i*4+2])<<8 | uint32_t(in[i*4+3]);
        for (unsigned i=16; i<64; ++i) {
            uint32_t a=w[i-15], b=w[i-2];
            w[i] = w[i-16]+(rotate(a,7)^rotate(a,18)^(a>>3))+w[i-7]+(rotate(b,17)^rotate(b,19)^(b>>10));
        }
        uint32_t a=state_[0],b=state_[1],c=state_[2],d=state_[3],e=state_[4],f=state_[5],g=state_[6],h=state_[7];
        for (unsigned i=0; i<64; ++i) {
            uint32_t t1=h+(rotate(e,6)^rotate(e,11)^rotate(e,25))+((e&f)^(~e&g))+k[i]+w[i];
            uint32_t t2=(rotate(a,2)^rotate(a,13)^rotate(a,22))+((a&b)^(a&c)^(b&c));
            h=g; g=f; f=e; e=d+t1; d=c; c=b; b=a; a=t1+t2;
        }
        state_[0]+=a; state_[1]+=b; state_[2]+=c; state_[3]+=d; state_[4]+=e; state_[5]+=f; state_[6]+=g; state_[7]+=h;
    }
public:
    void add(const unsigned char* p, size_t n) {
        bytes_+=n;
        while(n) {
            size_t used = std::min(n,64-buffered_);
            std::memcpy(buffer_+buffered_,p,used); buffered_+=used; p+=used; n-=used;
            if(buffered_==64) { block(buffer_); buffered_=0; }
        }
    }
    std::string finish() {
        uint64_t bits=bytes_*8;
        unsigned char suffix[128] = {0x80};
        size_t pad=buffered_<56 ? 56-buffered_ : 120-buffered_;
        for(unsigned i=0; i<8; ++i) suffix[pad+i]=static_cast<unsigned char>(bits>>(56-i*8));
        add(suffix,pad+8);
        const char* hex="0123456789abcdef"; std::string out;
        for(uint32_t s:state_) for(int i=7;i>=0;--i) out+=hex[(s>>(i*4))&15];
        return out;
    }
};
}
std::string sha256_file(const std::string& path,std::function<bool()> cancel) {
    FILE* f = std::fopen(path.c_str(),"rb");
    if(!f) throw std::runtime_error("Cannot read file for SHA-256");
    Hash hash; std::array<unsigned char,65536> b;
    size_t n;
    while((n=std::fread(b.data(),1,b.size(),f))) {
        if(cancel()) { std::fclose(f); throw std::runtime_error("Paused during file verification"); }
        hash.add(b.data(),n);
    }
    bool err=std::ferror(f); std::fclose(f);
    if(err) throw std::runtime_error("Read error during SHA-256");
    return hash.finish();
}
}
