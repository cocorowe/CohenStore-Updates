#include "cohen/store.hpp"
#include <curl/curl.h>
#include <cstdio>
#include <mutex>

namespace cohen {
namespace {
std::string trim(std::string s) {
    while(!s.empty() && std::isspace(static_cast<unsigned char>(s.back()))) s.pop_back();
    size_t p=0; while(p<s.size() && std::isspace(static_cast<unsigned char>(s[p]))) ++p;
    return s.substr(p);
}
struct Context {
    Response response; Headers headers; Body body; Cancel cancel; std::string error;
    bool accepted=false;
    static size_t header(char* p,size_t a,size_t b,void* opaque) {
        Context& c=*static_cast<Context*>(opaque); size_t n=a*b;
        try {
            std::string s(p,n);
            if(s.compare(0,5,"HTTP/")==0) {
                c.response=Response(); size_t gap=s.find(' ');
                if(gap!=std::string::npos) c.response.status=std::atoi(s.c_str()+gap+1);
            } else if(s=="\r\n" || s=="\n") {
                if(c.response.status>=200) { c.accepted=c.headers(c.response); if(!c.accepted) return 0; }
            } else {
                size_t colon=s.find(':');
                if(colon!=std::string::npos) c.response.headers[lower(trim(s.substr(0,colon)))]=trim(s.substr(colon+1));
            }
            return n;
        } catch(const std::exception& e) { c.error=e.what(); return 0; }
    }
    static size_t write(char* p,size_t a,size_t b,void* opaque) {
        Context& c=*static_cast<Context*>(opaque);
        try { return c.accepted && c.body(p,a*b) ? a*b : 0; }
        catch(const std::exception& e) { c.error=e.what(); return 0; }
    }
    static int progress(void* opaque,curl_off_t,curl_off_t,curl_off_t,curl_off_t) {
        return static_cast<Context*>(opaque)->cancel() ? 1 : 0;
    }
};
class CurlTransport : public Transport {
public:
    CurlTransport() {
        static std::once_flag once;
        std::call_once(once,[]{ if(curl_global_init(CURL_GLOBAL_DEFAULT)!=CURLE_OK) throw std::runtime_error("curl initialization failed"); });
    }
    std::string get(const std::string& url,const std::map<std::string,std::string>& headers,Headers h,Body b,Cancel cancel) override {
        allow_url(url);
        CURL* easy=curl_easy_init(); if(!easy) return "Cannot create HTTP client";
        Context c; c.headers=h; c.body=b; c.cancel=cancel;
        curl_slist* list=nullptr;
        for(const auto& kv:headers) list=curl_slist_append(list,(kv.first+": "+kv.second).c_str());
        char error[CURL_ERROR_SIZE]={};
        curl_easy_setopt(easy,CURLOPT_URL,url.c_str());
        curl_easy_setopt(easy,CURLOPT_HTTPHEADER,list);
        curl_easy_setopt(easy,CURLOPT_USERAGENT,"CohenStore/0.1");
        curl_easy_setopt(easy,CURLOPT_FOLLOWLOCATION,0L);
        curl_easy_setopt(easy,CURLOPT_SUPPRESS_CONNECT_HEADERS,1L);
        curl_easy_setopt(easy,CURLOPT_CONNECTTIMEOUT,15L);
        curl_easy_setopt(easy,CURLOPT_LOW_SPEED_LIMIT,1L);
        curl_easy_setopt(easy,CURLOPT_LOW_SPEED_TIME,30L);
        curl_easy_setopt(easy,CURLOPT_NOSIGNAL,1L);
        curl_easy_setopt(easy,CURLOPT_SSL_VERIFYPEER,1L);
        curl_easy_setopt(easy,CURLOPT_SSL_VERIFYHOST,2L);
        curl_easy_setopt(easy,CURLOPT_HEADERFUNCTION,Context::header);
        curl_easy_setopt(easy,CURLOPT_HEADERDATA,&c);
        curl_easy_setopt(easy,CURLOPT_WRITEFUNCTION,Context::write);
        curl_easy_setopt(easy,CURLOPT_WRITEDATA,&c);
        curl_easy_setopt(easy,CURLOPT_XFERINFOFUNCTION,Context::progress);
        curl_easy_setopt(easy,CURLOPT_XFERINFODATA,&c);
        curl_easy_setopt(easy,CURLOPT_NOPROGRESS,0L);
        curl_easy_setopt(easy,CURLOPT_ERRORBUFFER,error);
        CURLcode rc=curl_easy_perform(easy);
        curl_slist_free_all(list); curl_easy_cleanup(easy);
        if(!c.error.empty()) return c.error;
        if(rc!=CURLE_OK && c.accepted) return error[0]?error:curl_easy_strerror(rc);
        if(rc!=CURLE_OK && c.response.status==0) return error[0]?error:curl_easy_strerror(rc);
        return "";
    }
};
}
std::unique_ptr<Transport> make_transport() { return std::unique_ptr<Transport>(new CurlTransport()); }
}
