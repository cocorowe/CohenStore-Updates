#include "cohen/store.hpp"
#include <iostream>
#include <csignal>
#include <sys/stat.h>

namespace {
volatile std::sig_atomic_t interrupted=0;
void stop(int) { interrupted=1; }
}
int main(int argc,char** argv) {
    using namespace cohen;
    try {
        std::signal(SIGINT,stop);
        if(argc==3 && std::string(argv[1])=="hash") { std::cout<<sha256_file(argv[2])<<"\n"; return 0; }
        if(argc<3) {
            std::cerr<<"Cohen Store development client\n"
                     <<"  cohen-store list catalog.json\n"
                     <<"  cohen-store download catalog.json ITEM_ID DIRECTORY [RETRIES] [DELAY_MS]\n"
                     <<"  cohen-store refresh URL catalog.json\n"
                     <<"  cohen-store queue-check queue.json\n";
            return 2;
        }
        std::string cmd=argv[1];
        if(cmd=="queue-check") {
            auto jobs=load_queue(argv[2]);
            save_queue(std::string(argv[2])+".checked",jobs);
            std::cout<<jobs.size()<<" jobs loaded\n"; return 0;
        }
        auto transport=make_transport(); Engine engine(*transport);
        if(cmd=="refresh" && argc==4) {
            std::string text=engine.fetch_text(argv[2],[]{return interrupted!=0;});
            Catalog catalog=catalog_read(text);
            if(catalog.items.empty()) throw std::runtime_error("New catalog is empty; existing catalog kept");
            if(!catalog.warnings.empty()) throw std::runtime_error("Catalog contains invalid entries; existing catalog kept");
            write_atomic(argv[3],text); std::cout<<catalog.items.size()<<" entries refreshed\n"; return 0;
        }
        Catalog catalog=catalog_read(read_file(argv[2]));
        for(const auto& w:catalog.warnings) std::cerr<<w<<"\n";
        if(cmd=="list") {
            for(const auto& i:catalog.items) std::cout<<i.id<<"\t"<<i.title<<"\t"<<i.category<<"\t"<<i.size<<"\n";
            return 0;
        }
        if(cmd=="download" && argc>=5) {
            Options o; if(argc>5) o.retries=static_cast<unsigned>(std::stoul(argv[5]));
            if(argc>6) o.retry_delay_ms=static_cast<unsigned>(std::stoul(argv[6]));
            if(o.retries>20 || o.retry_delay_ms>30000) throw std::runtime_error("Retry settings out of range");
            for(const auto& i:catalog.items) if(i.id==argv[3]) {
                uint64_t last_mb=UINT64_MAX; std::string last_message;
                Result r=engine.download(i,argv[4],[&](const Progress& p) {
                    uint64_t mb=p.done/(1024*1024);
                    if(mb!=last_mb || p.message!=last_message) {
                        std::cerr<<p.message<<" ["<<p.done<<"/"<<p.total<<"] attempt "<<p.attempt<<"\n";
                        last_mb=mb; last_message=p.message;
                    }
                },[]{return interrupted!=0;},o);
                Json j=Json::obj(); j.object["ok"].kind=Json::Bool; j.object["ok"].text=r.ok?"true":"false";
                j.object["paused"].kind=Json::Bool; j.object["paused"].text=r.paused?"true":"false";
                j.object["path"]=Json(r.path); j.object["error"]=Json(r.error); j.object["bytes"]=Json::num(r.bytes);
                std::cout<<j.dump()<<"\n"; return r.ok?0:r.paused?3:1;
            }
            throw std::runtime_error("Unknown item id");
        }
        throw std::runtime_error("Unknown command or missing arguments");
    } catch(const std::exception& e) { std::cerr<<e.what()<<"\n"; return 1; }
}
