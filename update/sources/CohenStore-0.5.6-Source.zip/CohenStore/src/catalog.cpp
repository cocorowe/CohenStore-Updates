#include "cohen/store.hpp"
#include <algorithm>
#include <cerrno>
#include <cstdio>
#include <cstring>
#include <set>
#include <sys/stat.h>
#include <unistd.h>

namespace cohen {
std::string lower(std::string t) {
    for(char& c:t) c=char(std::tolower(static_cast<unsigned char>(c)));
    return t;
}
std::string read_file(const std::string& path, size_t limit) {
    FILE* f=std::fopen(path.c_str(),"rb");
    if(!f) throw std::runtime_error("Cannot open "+path+": "+std::strerror(errno));
    std::string out; char b[8192]; size_t n;
    while((n=std::fread(b,1,sizeof(b),f))) {
        if(out.size()+n>limit) { std::fclose(f); throw std::runtime_error("File exceeds size limit"); }
        out.append(b,n);
    }
    bool bad=std::ferror(f); std::fclose(f);
    if(bad) throw std::runtime_error("File read error");
    return out;
}
void write_atomic(const std::string& path, const std::string& content) {
    std::string tmp=path+".tmp";
    FILE* f=std::fopen(tmp.c_str(),"wb");
    if(!f) throw std::runtime_error("Cannot create "+tmp);
    bool good=std::fwrite(content.data(),1,content.size(),f)==content.size();
    if(std::fflush(f)!=0 || fsync(fileno(f))!=0) good=false;
    if(std::fclose(f)!=0) good=false;
    if(!good || std::rename(tmp.c_str(),path.c_str())!=0) throw std::runtime_error("Cannot save "+path);
}
Url parse_url(const std::string& s) {
    if(s.size()>8192 || s.empty()) throw std::runtime_error("Invalid URL length");
    for(unsigned char c:s) if(c<=32 || c==127 || c=='\\') throw std::runtime_error("URL contains whitespace or control characters");
    size_t sep=s.find("://");
    if(sep==std::string::npos) throw std::runtime_error("URL needs http:// or https://");
    Url u; u.scheme=lower(s.substr(0,sep));
    if(u.scheme!="http" && u.scheme!="https") throw std::runtime_error("Unsupported URL scheme");
    size_t start=sep+3,end=s.find_first_of("/?#",start);
    if(end==std::string::npos) end=s.size();
    u.authority=s.substr(start,end-start);
    if(u.authority.empty() || u.authority.find('@')!=std::string::npos || u.authority.find('%')!=std::string::npos)
        throw std::runtime_error("Invalid host or embedded credentials");
    u.host=lower(u.authority);
    if(u.host[0]=='[') {
        size_t close=u.host.find(']');
        if(close==std::string::npos) throw std::runtime_error("Invalid IPv6 host");
        u.host=u.host.substr(0,close+1);
    } else {
        size_t colon=u.host.find(':');
        if(colon!=std::string::npos) u.host=u.host.substr(0,colon);
        while(!u.host.empty() && u.host.back()=='.') u.host.pop_back();
        if(u.host.empty()) throw std::runtime_error("Empty host");
        for(char c:u.host) if(!std::isalnum(static_cast<unsigned char>(c)) && c!='.' && c!='-')
            throw std::runtime_error("Invalid hostname");
    }
    u.path=end==s.size()?"/":s.substr(end);
    if(u.path[0]!='/') u.path="/"+u.path;
    return u;
}
void allow_url(const std::string& s) {
    Url u=parse_url(s);
    if(u.host=="archive.org" || (u.host.size()>12 && u.host.compare(u.host.size()-12,12,".archive.org")==0))
        throw std::runtime_error("Internet Archive sources are excluded");
}
std::string resolve_url(const std::string& base, const std::string& location) {
    if(location.empty()) throw std::runtime_error("Redirect has no destination");
    Url u=parse_url(base); std::string out;
    if(location.find("://")!=std::string::npos) out=location;
    else if(location.compare(0,2,"//")==0) out=u.scheme+":"+location;
    else if(location[0]=='/') out=u.scheme+"://"+u.authority+location;
    else {
        std::string path=u.path.substr(0,u.path.find_first_of("?#"));
        if(location[0]=='?') out=u.scheme+"://"+u.authority+path+location;
        else out=u.scheme+"://"+u.authority+path.substr(0,path.rfind('/')+1)+location;
    }
    allow_url(out);
    if(u.scheme=="https" && parse_url(out).scheme!="https") throw std::runtime_error("HTTPS downgrade redirect refused");
    return out;
}
bool provider_page(const std::string& s) {
    Url u=parse_url(s);
    auto host_is=[&](const std::string& h){return u.host==h || (u.host.size()>h.size() && u.host.compare(u.host.size()-h.size()-1,h.size()+1,"."+h)==0);};
    return ((host_is("vikingfile.com") || host_is("vik1ngfile.site")) && u.path.compare(0,3,"/f/")==0)
        || ((host_is("akirabox.com") || host_is("akirabox.to")) && u.path.find("/uploads/")==std::string::npos)
        || host_is("1fichier.com")
        || (host_is("mediafire.com") && u.path.compare(0,6,"/file/")==0)
        || host_is("mega.nz") || host_is("gofile.io");
}
std::string item_key(const Item& i) {
    // Stable output name independent of catalog paths/titles.
    uint64_t h=14695981039346656037ULL;
    for(unsigned char c:i.id) { h^=c; h*=1099511628211ULL; }
    char b[17]; std::snprintf(b,sizeof(b),"%016llx",static_cast<unsigned long long>(h));
    return b;
}
Json Item::json() const {
    Json j=Json::obj(); j.object["id"]=Json(id); j.object["title"]=Json(title); j.object["category"]=Json(category);
    j.object["size_bytes"]=Json::num(size); j.object["sha256"]=Json(sha256); j.object["note"]=Json(note);
    j.object["app_version"]=Json(app_version); j.object["parent_title_id"]=Json(parent_title_id);
    j.object["region"]=Json(region); j.object["min_firmware"]=Json(min_firmware);
    j.object["format"]=Json(format); j.object["game"]=Json(game); j.object["source_url"]=Json(source_url);
    j.object["compatibility"]=Json(compatibility);
    Json versions=Json::arr(), ids=Json::arr();
    for(const auto& s:game_versions) versions.array.emplace_back(s);
    for(const auto& s:title_ids) ids.array.emplace_back(s);
    j.object["game_versions"]=versions; j.object["title_ids"]=ids;
    Json urls_j=Json::arr(); for(const auto& u:urls) urls_j.array.emplace_back(u);
    j.object["urls"]=urls_j; return j;
}
Item Item::from(const Json& j) {
    Item i; i.id=j.at("id").str(); i.title=j.at("title").str(); i.category=j.at("category").str("games");
    i.size=j.at("size_bytes").u64(); i.sha256=lower(j.at("sha256").str()); i.note=j.at("note").str();
    i.app_version=j.at("app_version").str(); i.parent_title_id=j.at("parent_title_id").str();
    i.region=j.at("region").str(); i.min_firmware=j.at("min_firmware").str();
    i.format=lower(j.at("format").str("pkg")); i.game=j.at("game").str();
    i.source_url=j.at("source_url").str(); i.compatibility=j.at("compatibility").str("Unverified");
    for(const auto& v:j.at("game_versions").array) i.game_versions.push_back(v.str());
    for(const auto& v:j.at("title_ids").array) i.title_ids.push_back(v.str());
    for(const Json& url:j.at("urls").array) i.urls.push_back(url.str());
    if(i.id.empty() || i.id.size()>1024 || i.title.empty() || i.title.size()>2048 || i.urls.size()>16 || (i.urls.empty() && i.source_url.empty()))
        throw std::runtime_error("Catalog entry needs an id, title, and download or creator URL");
    if(i.format!="pkg" && i.format!="prx") throw std::runtime_error("Unsupported file format");
    if(!i.source_url.empty()) allow_url(i.source_url);
    if(i.size>512ULL*1024*1024*1024) throw std::runtime_error("Package exceeds 512 GiB");
    if(!i.sha256.empty()) {
        if(i.sha256.size()!=64) throw std::runtime_error("Invalid SHA-256 length");
        for(char c:i.sha256) if(!std::isxdigit(static_cast<unsigned char>(c))) throw std::runtime_error("Invalid SHA-256");
    }
    for(const auto& url:i.urls) allow_url(url);
    return i;
}
Catalog catalog_read(const std::string& text) {
    Json root=Json::parse(text);
    if(root.kind!=Json::Object || root.at("schema").u64()!=1 || root.at("items").kind!=Json::Array)
        throw std::runtime_error("Expected Cohen Store catalog schema 1");
    Catalog c; std::set<std::string> ids,keys;
    for(const auto& j:root.at("items").array) {
        try {
            Item i=Item::from(j);
            if(!ids.insert(i.id).second || !keys.insert(item_key(i)).second) throw std::runtime_error("Duplicate catalog id");
            c.items.push_back(i);
        } catch(const std::exception& e) { c.warnings.push_back(j.at("title").str("Unnamed entry")+": "+e.what()); }
    }
    return c;
}
void save_queue(const std::string& path,const std::vector<Job>& jobs) {
    Json root=Json::obj(), a=Json::arr(); root.object["schema"]=Json::num(1);
    for(const auto& job:jobs) {
        Json j=Json::obj(); j.object["item"]=job.item.json(); j.object["state"]=Json(job.state); j.object["message"]=Json(job.message);
        a.array.push_back(j);
    }
    root.object["jobs"]=a; write_atomic(path,root.dump());
}
std::vector<Job> load_queue(const std::string& path) {
    struct stat st; if(stat(path.c_str(),&st)!=0 && errno==ENOENT) return {};
    Json root=Json::parse(read_file(path));
    if(root.at("schema").u64()!=1 || root.at("jobs").kind!=Json::Array) throw std::runtime_error("Invalid saved queue; keep it for recovery");
    std::vector<Job> jobs;
    for(const auto& j:root.at("jobs").array) {
        Job job; job.item=Item::from(j.at("item")); job.state=j.at("state").str("paused"); job.message=j.at("message").str();
        if(job.state=="downloading" || job.state=="queued") job.state="paused";
        jobs.push_back(job);
    }
    return jobs;
}
}
